<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Builld Amaze - Build Your Dream Home</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="icon" href="assets/img/logo2.jpg">
    <!-- CSS ============================================ -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- FontAwesome CSS 
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">-->
    <!-- Replace your old FA link with this -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="assets/css/flaticon.min.css">
    <!-- Slick Slider CSS -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- CSS Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/cssanimation.min.css">
    <!-- Justified Gallery CSS -->
    <link rel="stylesheet" href="assets/css/plugins/justifiedGallery.min.css">
    <!-- Light Gallery CSS -->
    <link rel="stylesheet" href="assets/css/plugins/light-gallery.min.css">
    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from avobe) -->
    <!--
		<link rel="stylesheet" href="assets/css/vendor.min.css">
		<link rel="stylesheet" href="assets/css/plugins/plugins.min.css">
		-->
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .header-area {
            background-color: rgb(3, 28, 56) !important;
            /* overrides data-bg image */
            color: #ffffff;
        }

        .header-area a {
            color: #ffffff;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .header-area a:hover {
            color: #ff9500;
            /* Accent color on hover */
        }

        .header-top-info__text {
            color: #ffffff;
        }

        .menu-bar-wrapper {
            background-color: rgb(255, 255, 255);
            /* Slightly lighter navy for contrast */
        }

        .menu-bar-wrapper-inner .main-nav-menu ul li a {
            color: rgb(0, 0, 0);
            font-weight: 600;
        }

        .menu-bar-wrapper-inner .main-nav-menu ul li a:hover {
            color: rgb(255, 200, 19);
        }

        .btn.btn-warning {
            background-color: #ff9500;
            border-color: #ff9500;
            color: #fff;
        }

        .btn.btn-warning:hover {
            background-color: #cc7600;
            border-color: #cc7600;
            color: #fff;
        }

        /* Icons inside header */
        .header-top-info__image img {
            filter: brightness(0) invert(1);
            /* Make icons white */
        }
    </style>
</head>

<body>
    <!--====================  header area ====================-->
    <div class="header-area header-sticky bg-img space__inner--y40 background-repeat--x  d-none d-lg-block">
        <!-- header top -->
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="header-top-info">
                            <span class="header-top-info__image pr-1"><img width="20" height="19" src="assets/img/icons/phone.webp" alt=""></span>
                            <span class="header-top-info__text"><a href="tel:+919900001718">+91-9900001718</a></span>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="header-top-info text-center">
                            <span class="header-top-info__image pr-1"><img width="19" height="19" src="assets/img/icons/clock.webp" alt=""></span>
                            <span class="header-top-info__text">Mon - Sat: 9:00-18:00</span>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="header-top-info text-end">
                            <span class="header-top-info__image pr-1"><img width="19" height="19" src="assets/img/mail.png" alt=""></span>
                            <span class="header-top-info__text"><a href="mailto:builldamaze@gmail.com" target='_blank'>builldamaze@gmail.com</a></span>
                        </div>
                    </div>
                    <!--<div class="col-lg-3">
                        <div class="header-top-info text-end">
                            <a class="header-top-info__link" href="login-register.php"><span>Login</span></a> / <a class="header-top-info__link" href="login-register.php">Register</a>
                        </div>
                    </div>-->
                </div>
            </div>
        </div>
        <!-- menu bar -->
        <div class="menu-bar">
            <div class="container1">
                <div class="row">
                    <div class="col-lg-12  position-relative">
                        <div class="menu-bar-wrapper background-color--default " style="padding-left: 80px;padding-right: 80px;">
                            <div class="menu-bar-wrapper-inner">
                                <div class="row align-items-center">
                                    <div class="col-lg-4 d-flex align-items-center">
                                        <div class="d-flex align-items-center">
                                            <!-- Logo -->
                                            <a href="index.php" class="me-3 mt-2">
                                                <img src="assets/img/logo2.jpg" class="img-fluid" alt="Company Logo" style="height: 65px;">
                                            </a>

                                            <!-- Company name and tagline -->
                                            <div class="company-info text-white">
                                                <h4 class=" fw-bold company-name">Builld Amaze</h4>
                                                <p class="mb-0 company-tagline">
                                                    ARCHITECTS, ENGINEERS & BUILDERS
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <style>
                                        @import url('https://fonts.googleapis.com/css2?family=Great+Vibes&family=Cardo:wght@700&display=swap');
                                        @import url('https://fonts.googleapis.com/css2?family=UnifrakturCook:700&display=swap');
                                        @import url('https://fonts.googleapis.com/css2?family=Lobster&display=swap');
                                        .company-name {
                                            font-family: 'Lobster', cursive;
                                            font-size: 28px;
                                            font-weight: bolder;
                                            color: rgb(3, 28, 56);
                                            /* margin-left: 6px; */
                                        }

                                        .company-tagline {
                                            font-family: 'Cardo', serif;
                                            font-size: 7px;
                                            font-weight: bold;
                                            color: rgb(3, 28, 56);
                                            /* letter-spacing: 1px; */
                                            text-transform: uppercase;
                                            text-align: center;
                                        }
                                    </style>

                                    <div class="col-lg-8">
                                        <div class="navigation-area d-flex justify-content-end align-items-center">
                                            <!-- navigation menu -->
                                            <nav class="main-nav-menu">
                                                <ul class="d-flex justify-content-end align-items-center">
                                                    <li><a href="index.php">HOME</a></li>

                                                    <!-- ABOUT with Dropdown -->
                                                    <li class="nav-item dropdown">
                                                        <a class="nav-link dropdown-toggle" href="about.php" id="navbarDropdown" role="button"
                                                            data-bs-toggle="dropdown" aria-expanded="false">
                                                            ABOUT
                                                        </a>
                                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                            <li><a class="dropdown-item" href="about.php#profile">Profile</a></li>
                                                            <li><a class="dropdown-item" href="about.php#process">Our Process</a></li>
                                                            <li><a class="dropdown-item" href="about.php#packages">Packages</a></li>
                                                        </ul>
                                                    </li>


                                                    <li><a href="residentialConstructionServices.php">RESIDENTIAL</a></li>
                                                    <li><a href="commercialConstructionServices.php">COMMERCIAL</a></li>
                                                    <li><a href="interiorDesigningServices.php">INTERIORS</a></li>
                                                    <li><a href="gallery.php">GALLERY</a></li>
                                                    <li><a href="contact.php">CONTACT</a></li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .main-nav-menu .dropdown-toggle::after {
                display: none !important;
            }
        </style>
    </div>
    <!--====================  End of header area  ====================-->
    <!--====================  mobile header ====================-->
    <div class="mobile-header  bg-img space__inner--y30 background-repeat--x  d-block d-lg-none">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-7">
                    <div class="d-flex align-items-center">
                        <!-- Logo -->
                        <a href="index.php" class="me-3 mt-2">
                            <img src="assets/img/logo2.jpg" class="img-fluid" alt="Company Logo" style="height: 65px;">
                        </a>

                        <!-- Company name and tagline -->
                        <div class="company-info text-white">
                            <h4 class=" fw-bold company-name">Builld Amaze</h4>
                            <p class="mb-0 company-tagline">
                                ARCHITECTS, ENGINEERS & BUILDERS
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="mobile-menu-trigger-wrapper text-end" id="mobile-menu-trigger">
                        <span class="mobile-menu-trigger"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of mobile header  ====================-->
    <!--====================  offcanvas mobile menu ====================-->
    <div class="offcanvas-mobile-menu" id="mobile-menu-overlay">
        <a href="javascript:void(0)" class="offcanvas-menu-close" id="mobile-menu-close-trigger">
            <span class="menu-close"></span>
        </a>
        <div class="offcanvas-wrapper">
            <div class="offcanvas-inner-content">
                <!--<div class="offcanvas-mobile-search-area">
                    <form action="#">
                        <input type="search" placeholder="Search ...">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>-->
                <nav class="offcanvas-navigation">
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="about.php">ABOUT</a></li>
                        <li><a href="residentialConstructionServices.php">RESIDENTIAL</a></li>
                        <li><a href="commercialConstructionServices.php">COMMERCIAL</a></li>
                        <li><a href="interiorDesigningServices.php">INTERIORS</a></li>
                        <li><a href="gallery.php">GALLERY</a></li>
                        <li><a href="contact.php">CONTACT</a></li>
                        <!-- <li><a href="#quick-enquery" class="btn btn-warning  py-1">Quick Enquiry</a></li> -->
                    </ul>
                </nav>
                <div class="offcanvas-widget-area">
                    <div class="off-canvas-contact-widget">
                        <div class="header-contact-info">
                            <ul class="header-contact-info__list">
                                <li><i class="fas fa-phone"></i> <a href="tel:+919900001718">+91-9900001718</a> </li>
                                <li><i class="fas fa-clock"></i> 9.00 am - 6.00 pm</li>
                                <li><i class="fas fa-envelope"></i><a href="mailto:builldamaze@gmail.com" target='_blank'>builldamaze@gmail.com</a></li>
                                <!--<li><i class="fa fa-user"></i> <a href="login-register.php">Login / Register</a></li>-->
                            </ul>
                        </div>
                    </div>
                    <!--Off Canvas Widget Social Start-->
                    <div class="off-canvas-widget-social">
                        <a href="https://www.instagram.com/builldamaze/"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.youtube.com/@builldamaze"><i class="fab fa-youtube"></i></a>
                        <!-- <a href="https://www.google.co.in/search?_ga=2.58808877.1413448851.1594754065-2045706217.1594045386&q=BuildIT&ludocid=17328132553542417044&lsig=AB86z5V9ysani4hE8yF-SAm4WKPy&gws_rd=ssl#gws_rd=ssl"><i class="fa fa-google"></i></a> -->
                    </div>
                    <!--Off Canvas Widget Social End-->
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of offcanvas mobile menu  ====================-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>