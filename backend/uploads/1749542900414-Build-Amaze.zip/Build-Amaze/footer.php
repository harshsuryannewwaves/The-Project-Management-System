<style>
    .footer-area {
        font-family: 'Segoe UI', sans-serif;
    }

    .footer-widget__title {
        font-size: 18px;
        font-weight: 700;
        color: #facc15;
    }

    .footer-widget__menu li {
        margin-bottom: 10px;
    }

    .footer-widget__menu li a {
        color: #ddd;
        text-decoration: none;
        transition: color 0.3s;
    }

    .footer-widget__menu li a:hover {
        color: #facc15;
    }

    .social-icon {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        font-size: 16px;
        transition: transform 0.3s ease;
    }

    .social-icon.instagram {
        background-color: #E4405F;
    }

    .social-icon.youtube {
        background-color: #FF0000;
    }

    .social-icon:hover {
        transform: scale(1.1);
    }

    .map-container iframe {
        border-radius: 8px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.25);
    }

    @media (max-width: 767px) {
        .footer-area {
            text-align: center;
        }

        .footer-widget {
            margin-bottom: 2rem;
        }
    }
</style>

<style>
    @media (max-width: 768px) {
        .floating-social-icons {
            right: 50px !important;
        }
    }

    @media (max-width: 767px) {
        .social-list {
            display: none !important;
        }
    }
</style>

<!--====================  footer area ====================-->
<div class="footer-area py-5 position-relative text-white" style="font-family: Rajdhani, sans-serif;background: url('https://img.freepik.com/premium-vector/blue-skyline-with-modern-construction-site-silhouettes-building-with-scaffolds_88272-8833.jpg?semt=ais_hybrid&w=740') center/cover no-repeat;">
    <div style="position: absolute; top: 0; left: 0; height: 100%; width: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 1;"></div>
    <div class="container position-relative z-2" style="z-index: 2;">
        <div class="row gy-5">
            <!-- Logo & Description -->
            <div class="col-lg-3 col-md-6">
                <div class="footer-widget">
                    <div class="footer-widget__logo mb-3">
                        <a href="index.php">
                            <img src="assets/img/logo3.jpg" alt="Build Amaze Logo" width="150" class="img-fluid">
                        </a>
                    </div>
                    <p class="mb-3">A new way to construction & renovation — the ultimate solution to build a home.</p>
                    <ul class="social-list d-flex gap-3 ps-0" style="list-style: none;">
                        <li>
                            <a href="https://www.instagram.com/builldamaze/" target="_blank" class="social-icon instagram">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/@builldamaze" target="_blank" class="social-icon youtube">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Navigation Links -->
            <div class="col-lg-2 col-md-6">
                <div class="footer-widget">
                    <h5 class="footer-widget__title mb-3">Information</h5>
                    <ul class="footer-widget__menu list-unstyled">
                        <li><a href="residentialConstructionServices.php">Residential</a></li>
                        <li><a href="commercialConstructionServices.php">Commercial</a></li>
                        <li><a href="interiorDesigningServices.php">Interiors</a></li>
                        <li><a href="gallery.php">Gallery</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>

            <!-- Contact Info -->
            <div class="col-lg-3 col-md-6">
                <div class="footer-widget">
                    <h5 class="footer-widget__title mb-3">Contact Us</h5>
                    <div class="d-flex mb-2">
                        <i class="fas fa-map-marker-alt text-warning me-2"></i>
                        <a href="https://maps.app.goo.gl/otVz3rgpMux8PUGUA" target="_blank" class="text-white text-decoration-none">
                            943, 10th Cross, 13th Main Rd, Srinagar, Bengaluru, Karnataka 560050
                        </a>
                    </div>
                    <div class="d-flex mb-2">
                        <i class="fas fa-phone-volume text-warning me-2"></i>
                        <a href="tel:9900001718" class="text-white text-decoration-none">+91 99000 01718</a>
                    </div>
                    <div class="d-flex">
                        <i class="fas fa-envelope text-warning me-2"></i>
                        <a href="mailto:builldamaze@gmail.com" class="text-white text-decoration-none">builldamaze@gmail.com</a>
                    </div>
                </div>
            </div>

            <!-- Google Map -->
            <div class="col-lg-4 col-md-5">
                <div class="footer-widget">
                    <h5 class="footer-widget__title mb-3">Our Location</h5>
                    <div class="map-container">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3913.716085367284!2d77.550753575076!3d12.946174387366895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3f301d03a821%3A0x2c7cae8452385b92!2sBuilld%20Amaze!5e1!3m2!1sen!2sin!4v1749100513714!5m2!1sen!2sin" width="400" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- copyright text -->
<div style="background-color:rgba(0, 0, 0, 0.8);" class="copyright-area  space__inner--y10">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <p class="copyright-text text-white">&copy; Builld Amaze 2018-2025</p>
            </div>
        </div>
    </div>
</div>
<!-- Social Media Floating Buttons -->
<div class="floating-social-icons" style="position: fixed; right: 10px; bottom: 200px; z-index: 999; display: flex; flex-direction: column; gap: 15px; align-items: center;">

    <!-- WhatsApp -->
    <a href="https://api.whatsapp.com/send?phone=919900001718&text=Hi,%20Welcome%20to%20BuilldAmaze.%20The%20leading%20and%20Trusted%20House%20construction%20contractors%20in%20Bangalore!%20We%20will%20arrange%20a%20callback%20for%20you%20shortly.%20Thanks.%20"
        target="_blank"
        style="width: 50px; height: 50px; background-color: #25D366; border-radius: 50%; display: flex; justify-content: center; align-items: center; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
        <i class="fab fa-whatsapp" style="color: white; font-size: 24px;"></i>
    </a>

    <!-- Instagram -->
    <a href="https://www.instagram.com/builldamaze/"
        target="_blank"
        style="width: 50px; height: 50px; background-color: #E4405F; border-radius: 50%; display: flex; justify-content: center; align-items: center; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
        <i class="fab fa-instagram" style="color: white; font-size: 24px;"></i>
    </a>

    <!-- YouTube -->
    <a href="https://www.youtube.com/@builldamaze"
        target="_blank"
        style="width: 50px; height: 50px; background-color: #FF0000; border-radius: 50%; display: flex; justify-content: center; align-items: center; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
        <i class="fab fa-youtube" style="color: white; font-size: 24px;"></i>
    </a>

</div>


<!--====================  End of footer area  ====================-->
<!--====================  scroll top ====================-->
<button class="scroll-top" id="scroll-top">
    <i class="fa fa-angle-up"></i>
</button>
<!--====================  End of scroll top  ====================-->
<!-- JS
    ============================================ -->
<!-- Modernizer JS -->
<script src="assets/js/modernizr-2.8.3.min.js"></script>
<!-- jQuery JS -->
<script src="assets/js/jquery.min.js"></script>
<!-- Popper JS -->
<script src="assets/js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Slick slider JS -->
<script src="assets/js/plugins/slick.min.js"></script>
<!-- Counterup JS -->
<script src="assets/js/plugins/counterup.min.js"></script>
<!-- Waypoint JS -->
<script src="assets/js/plugins/waypoint.min.js"></script>
<!-- Justified Gallery JS -->
<script src="assets/js/plugins/justifiedGallery.min.js"></script>
<!-- Image Loaded JS -->
<script src="assets/js/plugins/imageloaded.min.js"></script>
<!-- Maosnry JS -->
<script src="assets/js/plugins/masonry.min.js"></script>
<!-- Light Gallery JS -->
<script src="assets/js/plugins/light-gallery.min.js"></script>
<!-- Mailchimp JS -->
<script src="assets/js/plugins/mailchimp-ajax-submit.min.js"></script>
<!-- Plugins JS (Please remove the comment from below plugins.min.js for better website load performance and remove plugin js files from avobe) -->
<!--
    <script src="assets/js/plugins/plugins.min.js"></script>
    -->
<!-- Main JS -->
<script src="assets/js/main.js"></script>
</body>

</html>