<?php include('header.php'); ?>
<style>
    .header-top-info {
        display: flex !important;
        align-items: center !important;
    }

    .header-top-info.text-end {
        justify-content: flex-end !important;
    }

    .header-top-info.text-center {
        justify-content: center !important;
    }

    .header-top-info__image {
        padding-right: 0.5rem !important;
    }
</style>
<style>
/* Contact Form Styles */
.contact-form {
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
}

/* Input + Textarea */
.contact-form input,
.contact-form textarea {
    border: 1px solid #ced4da;
    border-radius: 8px;
    padding: 12px 16px;
    font-size: 15px;
    transition: all 0.3s ease;
    background-color: #fdfdfd;
    color: #333;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.03);
}

.contact-form input:focus,
.contact-form textarea:focus {
    border-color: #facc15;
    background-color: #fffbe6;
    box-shadow: 0 0 5px rgba(250, 204, 21, 0.3);
    outline: none;
}

/* Captcha Fields */
.contact-form .form-control.text-center {
    padding: 10px;
    font-weight: bold;
}

/* Button Style */
.contact-form button {
    background-color: #facc15;
    color: #fff;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    padding: 12px 28px;
    transition: background-color 0.3s ease, transform 0.2s ease;
    font-size: 16px;
}

.contact-form button:hover {
    background-color: #e0b800;
    transform: translateY(-2px);
}

</style>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: '#1e40af', // Deep blue
                    secondary: '#fcd34d' // Warm yellow
                }
            }
        }
    }
</script>
<style>
    @media only screen and (max-width: 767px) {
        #hero-section-about {
            margin-top: 0px;
        }
    }
</style>
<!--====================  breadcrumb area ====================-->
<section id="hero-section-about" class="z-0 relative  text-white  pt-4 pb-1 sm:mt-0 lg:mt-[5rem]" style="background-color: #17263b;">
    <!-- <div class="absolute inset-0 opacity-20 bg-pattern"></div> -->
    <div class=" mx-auto px-4 text-center relative z-10">
        <h1 class="text-4xl md:text-6xl font-bold mb-6 text-white">Contact Us</h1>
    </div>
</section>
<!--====================  End of breadcrumb area  ====================-->
<!--====================  contact area ====================-->
<div class="conact-section mt-20">
    <div class="container">
        <div class="row">
            <div class="col space__bottom--40">
                <div class="contact-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3913.716085367284!2d77.550753575076!3d12.946174387366895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3f301d03a821%3A0x2c7cae8452385b92!2sBuilld%20Amaze!5e1!3m2!1sen!2sin!4v1749100513714!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
        <div class="row">
    <!-- Contact Info -->
    <div class="col-lg-4 col-12">
        <div class="contact-information p-4 border rounded shadow-sm bg-light h-100">
            <h4 class="mb-4  fw-bold" style="color: #17263b;">Contact Information</h4>
            <ul class="list-unstyled">
                <li class="d-flex align-items-start mb-3">
                    <span class="icon me-3 text-warning fs-5"><i class="fas fa-location-dot"></i></span>
                    <span class="text"><a class="text-dark text-decoration-none" href="https://maps.app.goo.gl/otVz3rgpMux8PUGUA" target="_blank">943, 10th Cross, 13th Main Rd, Srinagar, Bengaluru, Karnataka 560050</a></span>
                </li>
                <li class="d-flex align-items-start mb-3">
                    <span class="icon me-3 text-warning fs-5"><i class="fas fa-phone-volume"></i></span>
                    <span class="text"><a class="text-dark text-decoration-none" href="tel:9535873248">+91 9900001718</a></span>
                </li>
                <li class="d-flex align-items-start">
                    <span class="icon me-3 text-warning fs-5"><i class="fas fa-envelope"></i></span>
                    <span class="text"><a class="text-dark text-decoration-none" href="mailto:builldamaze@gmail.com" target="_blank">builldamaze@gmail.com</a></span>
                </li>
            </ul>
        </div>
    </div>

    <!-- Contact Form -->
    <div class="col-lg-8 col-12">
    <div class="contact-form">
        <h4 class="mb-4  fw-bold" style="color: #17263b;">Leave Your Message</h4>
        <form action="send-mail.php" method="post">
            <div class="row g-3">
                <div class="col-md-4 col-12">
                    <input name="name" type="text" class="form-control" placeholder="Your Name" required>
                </div>
                <div class="col-md-4 col-12">
                    <input name="email" type="email" class="form-control" placeholder="Your Email" required>
                </div>
                <div class="col-md-4 col-12">
                    <input name="phone" type="number" class="form-control" placeholder="Your Phone No." required>
                </div>
                <div class="col-12">
                    <textarea name="message" class="form-control" rows="4" placeholder="Your Message"></textarea>
                </div>
                <div class="col-12 d-flex gap-2 flex-wrap align-items-center">
                    <input id="num1" readonly name="num1"
                        style="width: 30%; padding: 8px; text-align: center; font-size: 13px; border-radius: 6px; border: 1px solid #999;"
                        value="<?php echo rand(1, 4) ?>">
                    <strong class="fs-6">+</strong>
                    <input id="num2" readonly name="num2"
                        style="width: 30%; padding: 8px; text-align: center; font-size: 13px; border-radius: 6px; border: 1px solid #999;"
                        value="<?php echo rand(5, 9) ?>">
                    <strong class="fs-6">=</strong>
                    <input id="captcha" name="captcha" required maxlength="2"
                        style="width: 30%; padding: 8px; text-align: center; font-size: 13px; border-radius: 6px; border: 1px solid #999;"
                        placeholder="??">
                </div>
                <div class="col-12">
                    <button type="submit">Send Message</button>
                </div>
            </div>
        </form>
    </div>
</div>

</div>


    </div>
</div>
<br>
<!--====================  End of contact area  ====================-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include('footer.php'); ?>