<?php include('header.php'); ?>

<style>
    .header-top-info {
        display: flex !important;
        align-items: center !important;
    }

    .header-top-info.text-end {
        justify-content: flex-end !important;
    }

    .header-top-info.text-center {
        justify-content: center !important;
    }

    .header-top-info__image {
        padding-right: 0.5rem !important;
    }
</style>

<script src="https://cdn.tailwindcss.com"></script>
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->

<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: '#17263b',
                    secondary: '#F59E0B',
                    darkblue: '#17263b',
                    lightyellow: '#FEF3C7'
                }
            }
        }
    }
</script>

<!-- Hero Section -->

<div class="relative overflow-hidden gradient-highlight sm:mt-0 lg:mt-[80px]" style="background-color: #17263b;">
    <div class="container mx-auto px-4 py-16 text-center">
        <h1 class="text-4xl md:text-6xl font-bold text-white mb-6">
            <span class="block">Your Dream Home</span>
            <!-- <span class="text-yellow-300">Services</span> -->
        </h1>
        <p class="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Built to Perfection
        </p>
    </div>
    <div class="absolute bottom-0 left-0 right-0 h-2 bg-yellow-400"></div>
</div>

<!-- About Section -->
<!-- <section id="about" class="py-16 bg-lightyellow">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row items-center">
            <div class="md:w-1/2 mb-10 md:mb-0 md:pr-10">
                <div class="relative">
                    <img src="assets/img/residential/inter1.jpg"
                        alt="Construction Team"
                        class="rounded-lg shadow-xl w-full">
                    <div class="absolute -bottom-6 -right-6  text-white p-6 rounded-lg shadow-lg max-w-xs" style="background-color: #17263b;">
                        <h3 class="font-bold text-xl mb-2 text-white">15+ Years Experience</h3>
                        <p class="text-sm">Trusted by homeowners across Bangalore</p>
                    </div>
                </div>
            </div>
            <div class="md:w-1/2">
                <h2 class="text-3xl font-bold  mb-6" style="color: #17263b;">About BuilldAmaze</h2>
                <p class="text-gray-700 mb-4">At BuilldAmaze, we understand that your home is more than just a structure; it's a reflection of your dreams, aspirations, and lifestyle. As one of Bangalore's most trusted and leading residential house construction contractors, we are dedicated to transforming your vision into a living reality.</p>
                <p class="text-gray-700 mb-6">With meticulous attention to detail and an unwavering commitment to quality, we craft homes that stand as a testament to exceptional design, enduring quality, and personalized comfort.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <div class="flex items-start">
                        <i class="fa fa-check-circle text-secondary text-xl mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-bold " style="color: #17263b;">Quality Materials</h4>
                            <p class="text-gray-600 text-sm">Only the best materials for lasting durability</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <i class="fa fa-check-circle text-secondary text-xl mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-bold " style="color: #17263b;">Skilled Professionals</h4>
                            <p class="text-gray-600 text-sm">Highly trained and experienced craftsmen</p>
                        </div>
                    </div>
                </div>
                <a href="about.php" class="inline-flex items-center font-bold hover:text-darkblue" style="color: #17263b;">
                    Learn More About Us
                    <i class="fa fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</section>                       -->

<!-- Services Section -->
<section id="services" class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold  mb-4" style="color: #17263b;">Our Comprehensive Residential Construction Services</h2>
            <div class="w-24 h-1  mx-auto" style="background-color: rgb(245 158 11 / var(--tw-bg-opacity, 1));"></div>
            <p class="text-gray-600 mt-4 max-w-3xl mx-auto">From the initial concept to the final handover, BuilldAmaze offers an end-to-end suite of residential construction services.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="service-card group bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transform transition duration-300 hover:scale-105">

                <div class=" p-6 text-white" style="background-color: #17263b;">
                    <i class="fa fa-drafting-compass text-4xl mb-4 text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                    <h3 class="text-xl font-bold mb-2 text-white">Custom Home Builds</h3>
                </div>
                <div class="p-6 " >
                    <p class="text-gray-600 mb-4">Whether you envision a contemporary masterpiece, a traditional family abode, or a sprawling luxury villa, our team specializes in crafting bespoke homes tailored precisely to your unique specifications and desires.</p>
                    
                </div>
            </div>

            <div class="service-card group bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transform transition duration-300 hover:scale-105">

                <div class=" p-6 text-white" style="background-color: #17263b;">
                    <i class="fa fa-pencil-ruler text-4xl mb-4 text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                    <h3 class="text-xl font-bold mb-2 text-white">Architectural Design</h3>
                </div>
                <div class="p-6">
                    <p class="text-gray-600 mb-4">Our in-house team of experienced architects and consultants collaborates closely with you to develop innovative, functional, and aesthetically pleasing designs that optimize space, natural light, and flow.</p>
                    
                </div>
            </div>

            <div class="service-card group bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transform transition duration-300 hover:scale-105">

                <div class=" p-6 text-white" style="background-color: #17263b;">
                    <i class="fa fa-hammer text-4xl mb-4 text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                    <h3 class="text-xl font-bold mb-2 text-white">Structural Engineering</h3>
                </div>
                <div class="p-6">
                    <p class="text-gray-600 mb-4">We employ advanced engineering principles and robust construction techniques to ensure the structural integrity and longevity of your home, starting with a strong and stable foundation.</p>
                   
                </div>
            </div>

            <div class="service-card group bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transform transition duration-300 hover:scale-105">

                <div class=" p-6 text-white" style="background-color: #17263b;">
                    <i class="fa fa-couch text-4xl mb-4 text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                    <h3 class="text-xl font-bold mb-2 text-white">Interior Design</h3>
                </div>
                <div class="p-6">
                    <p class="text-gray-600 mb-4">Our interior designers work in harmony with the architectural plan, selecting premium materials, fixtures, and finishes to create interiors that are beautiful and personalized to your taste.</p>
                   
                </div>
            </div>

            <div class="service-card group bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transform transition duration-300 hover:scale-105">

                <div class=" p-6 text-white" style="background-color: #17263b;">
                    <i class="fa fa-project-diagram text-4xl mb-4 text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                    <h3 class="text-xl font-bold mb-2 text-white">Project Management</h3>
                </div>
                <div class="p-6">
                    <p class="text-gray-600 mb-4">A dedicated project manager oversees every phase of construction, ensuring strict adherence to timelines, budgets, and quality standards while maintaining transparent communication.</p>
                   
                </div>
            </div>

            <div class="service-card group bg-white rounded-lg shadow-md overflow-hidden border border-gray-800 transform transition duration-300 hover:scale-105">

                <div class=" p-6 text-white" style="background-color: #17263b;">
                    <i class="fa fa-clipboard-check text-4xl mb-4 text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                    <h3 class="text-xl font-bold mb-2 text-white">Quality Assurance</h3>
                </div>
                <div class="p-6">
                    <p class="text-gray-600 mb-4">Before handover, every aspect of your new home undergoes rigorous quality checks. We ensure all systems are functioning perfectly and provide you with a comprehensive guide to your new residence.</p>
                   
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose Us Section -->
<section class="py-16 bg-lightyellow">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold  mb-4" style="color: #17263b;">Why Choose BuilldAmaze?</h2>
            <div class="w-24 h-1 bg-secondary mx-auto"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Integrated Expertise -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border border-gray-200 transform transition duration-300 hover:scale-105">
                <div class=" w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4" style="background-color: #17263b;">
                    <i class="fa fa-sitemap text-3xl text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                </div>
                <h3 class="text-xl font-bold  mb-4" style="color: #17263b;">Integrated Expertise</h3>
                <p class="text-gray-600">Our in-house team of architects, consultants, designers and skilled builders work collaboratively for a cohesive construction process.</p>
            </div>

            <!-- Uncompromising Quality -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border border-gray-200 transform transition duration-300 hover:scale-105">
                <div class=" w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4" style="background-color: #17263b;">
                    <i class="fa fa-star text-3xl text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                </div>
                <h3 class="text-xl font-bold  mb-4" style="color: #17263b;">Uncompromising Quality</h3>
                <p class="text-gray-600">We utilize only the highest quality materials and adhere to stringent construction practices for durability, safety and superior finish.</p>
            </div>

            <!-- Transparent Process -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border border-gray-200 transform transition duration-300 hover:scale-105">
                <div class=" w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4" style="background-color: #17263b;">
                    <i class="fa fa-file-text text-3xl text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                </div>
                <h3 class="text-xl font-bold  mb-4" style="color: #17263b;">Transparent Process</h3>
                <p class="text-gray-600">We believe in complete transparency with detailed cost breakdowns and regular progress updates throughout your project.</p>
            </div>

            <!-- Timely Delivery -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border border-gray-200 transform transition duration-300 hover:scale-105">
                <div class=" w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4" style="background-color: #17263b;">
                    <i class="fa fa-clock text-3xl text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                </div>
                <h3 class="text-xl font-bold  mb-4" style="color: #17263b;">Timely Delivery</h3>
                <p class="text-gray-600">Our efficient project management ensures that your home is delivered on schedule, without compromising on quality or craftsmanship.</p>
            </div>

            <!-- Customer-Centric Approach -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border border-gray-200 transform transition duration-300 hover:scale-105">
                <div class=" w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4" style="background-color: #17263b;">
                    <i class="fa fa-user text-3xl text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                </div>
                <h3 class="text-xl font-bold  mb-4" style="color: #17263b;">Customer-Centric Approach</h3>
                <p class="text-gray-600">Your satisfaction is our paramount concern. We listen intently to your needs, offer expert guidance, and are dedicated to exceeding your expectations.</p>
            </div>

            <!-- Bangalore's Trusted Name -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border border-gray-200 transform transition duration-300 hover:scale-105">
                <div class=" w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4" style="background-color: #17263b;">
                    <i class="fa fa-building text-3xl text-secondary text-white transition-transform duration-500 group-hover:rotate-[360deg]"></i>
                </div>
                <h3 class="text-xl font-bold  mb-4" style="color: #17263b;">Bangalore's Trusted Name</h3>
                <p class="text-gray-600">With a proven track record of delivering exceptional homes across Bangalore, Builld Amaze has earned a reputation for reliability, integrity, and excellence.</p>
            </div>
        </div>
    </div>
</section>



<!-- Projects Gallery -->
<section id="projects" class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold  mb-4" style="color: #17263b;">Our Recent Projects</h2>
            <div class="w-24 h-1 bg-secondary mx-auto"></div>
            <p class="text-gray-600 mt-4 max-w-3xl mx-auto">Browse through our portfolio of exceptional residential projects in Bangalore.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/residential/inter2.jpeg"
                    alt="Modern Villa Project"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/residential/inter3.jpg"
                    alt="Contemporary Apartment"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/residential/inter4.jpg"
                    alt="Heritage Bungalow"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/residential/2012-08-03 11.43.41_1_11zon.jpg"
                    alt="Luxury Penthouse"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/residential/private_8_8_11zon.webp"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/residential/WhatsApp Image 2023-06-28 at 7.20.54 PM (1)_9_11zon.jpg"
                    alt="Gated Community"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div id="imageModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black bg-opacity-70">
    <div class="relative bg-white p-4 rounded-lg shadow-lg max-w-2xl w-full max-h-[65vh] overflow-auto">
        <button onclick="closeModal()" class="absolute top-2 right-1 text-black text-6xl font-bold">&times;</button>

        <!-- Left Arrow -->
        <button onclick="prevImage()" class="absolute left-1 top-1/2 transform -translate-y-1/2 text-4xl text-gray-600 hover:text-black z-10">
            &#10094;
        </button>

        <!-- Right Arrow -->
        <button onclick="nextImage()" class="absolute right-1 top-1/2 transform -translate-y-1/2 text-4xl text-gray-600 hover:text-black z-10">
            &#10095;
        </button>

        <img id="modalImage" src="" alt="Project Image" class="w-full h-auto rounded">
    </div>
</div>
<style>
    #imageModal button {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0 10px;
}

</style>


<!-- CTA Section -->
<section class="py-16 bg-gradient-to-r from-primary to-darkblue text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6 text-yellow-500">Begin Your Home Building Journey with Builld Amaze</h2>
        <p class="text-xl mb-8 max-w-2xl mx-auto">Imagine stepping into a home that perfectly encapsulates your vision, built with unparalleled craftsmanship and attention to every detail. With Build Amaze, this dream is within reach.</p>

    </div>
</section>

<!-- Contact Section -->
<!-- <section id="contact" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row">
                <div class="md:w-1/2 mb-10 md:mb-0 md:pr-10">
                    <h2 class="text-3xl font-bold text-primary mb-6">Get In Touch</h2>
                    <p class="text-gray-600 mb-8">Have questions about building your dream home? Our team is here to help. Contact us today to schedule a consultation.</p>
                    
                    <div class="space-y-6">
                        <div class="flex items-start">
                            <div class="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                                <i class="fas fa-map-marker-alt text-lg"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-primary mb-1">Our Office</h4>
                                <p class="text-gray-600">#123, BuildAmaze Towers, Brigade Road, Bangalore - 560001</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                                <i class="fas fa-phone-alt text-lg"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-primary mb-1">Call Us</h4>
                                <p class="text-gray-600">+91 9876543210</p>
                                <p class="text-gray-600">080 12345678</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-primary/10 p-3 rounded-full mr-4 text-primary">
                                <i class="fas fa-envelope text-lg"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-primary mb-1">Email Us</h4>
                                <p class="text-gray-600">info@buildamaze.com</p>
                                <p class="text-gray-600">support@buildamaze.com</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-8">
                        <h4 class="font-bold text-primary mb-4">Connect With Us</h4>
                        <div class="flex space-x-4">
                            <a href="#" class="bg-primary/10 text-primary w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary hover:text-white transition duration-300">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="bg-primary/10 text-primary w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary hover:text-white transition duration-300">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="bg-primary/10 text-primary w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary hover:text-white transition duration-300">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="bg-primary/10 text-primary w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary hover:text-white transition duration-300">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="md:w-1/2">
                    <div class="bg-gray-50 p-8 rounded-lg shadow-md">
                        <h3 class="text-2xl font-bold text-primary mb-6">Send Us a Message</h3>
                        <form>
                            <div class="mb-4">
                                <label for="name" class="block text-gray-700 font-medium mb-2">Name</label>
                                <input type="text" id="name" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                            </div>
                            <div class="mb-4">
                                <label for="email" class="block text-gray-700 font-medium mb-2">Email</label>
                                <input type="email" id="email" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                            </div>
                            <div class="mb-4">
                                <label for="phone" class="block text-gray-700 font-medium mb-2">Phone</label>
                                <input type="tel" id="phone" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                            </div>
                            <div class="mb-4">
                                <label for="service" class="block text-gray-700 font-medium mb-2">Service Interested In</label>
                                <select id="service" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                                    <option value="">Select a service</option>
                                    <option value="custom-home">Custom Home Build</option>
                                    <option value="design">Architectural Design</option>
                                    <option value="renovation">Home Renovation</option>
                                    <option value="interior">Interior Design</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="mb-6">
                                <label for="message" class="block text-gray-700 font-medium mb-2">Message</label>
                                <textarea id="message" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"></textarea>
                            </div>
                            <button type="submit" class="w-full bg-primary hover:bg-darkblue text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

<!-- FAQ Section -->
<!-- <section class="py-16 bg-lightyellow">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-primary mb-4">Frequently Asked Questions</h2>
                <div class="w-24 h-1 bg-secondary mx-auto"></div>
            </div>
            
            <div class="max-w-3xl mx-auto space-y-4">
                <div class="border border-primary/30 rounded-lg overflow-hidden">
                    <button class="faq-toggle w-full p-4 text-left bg-white flex justify-between items-center">
                        <span class="text-lg font-medium text-primary">How long does it typically take to build a custom home?</span>
                        <i class="fa fa-plus text-secondary"></i>
                    </button>
                    <div class="faq-content hidden p-4 bg-white/50">
                        <p class="text-gray-700">The timeline for building a custom home varies depending on the size, complexity, and design specifications. Typically, a custom home takes between 9-18 months from initial design to completion. Smaller projects may take as little as 6 months, while larger luxury homes can take up to 24 months. We provide a detailed timeline during the planning phase based on your specific project.</p>
                    </div>
                </div>
                
                <div class="border border-primary/30 rounded-lg overflow-hidden">
                    <button class="faq-toggle w-full p-4 text-left bg-white flex justify-between items-center">
                        <span class="text-lg font-medium text-primary">What is included in your construction costs?</span>
                        <i class="fa fa-plus text-secondary"></i>
                    </button>
                    <div class="faq-content hidden p-4 bg-white/50">
                        <p class="text-gray-700">Our construction costs include all labor, materials (as specified in your contract), project management, quality control, and compliance with building codes and regulations. We provide transparent, detailed cost breakdowns before any work begins. Some elements like specialized fixtures or high-end finishes may be additional based on your selections. We always discuss and approve any changes that affect the budget.</p>
                    </div>
                </div>
                
                <div class="border border-primary/30 rounded-lg overflow-hidden">
                    <button class="faq-toggle w-full p-4 text-left bg-white flex justify-between items-center">
                        <span class="text-lg font-medium text-primary">Do you handle obtaining permits and approvals?</span>
                        <i class="fa fa-plus text-secondary"></i>
                    </button>
                    <div class="faq-content hidden p-4 bg-white/50">
                        <p class="text-gray-700">Yes, we fully manage the permit and approval process as part of our comprehensive service. Our team is experienced in navigating local building regulations and municipal requirements in Bangalore. We'll handle all documentation, submissions, and coordination with authorities. This includes structural approvals, environmental clearances (if needed), and final occupancy certificates.</p>
                    </div>
                </div>
                
                <div class="border border-primary/30 rounded-lg overflow-hidden">
                    <button class="faq-toggle w-full p-4 text-left bg-white flex justify-between items-center">
                        <span class="text-lg font-medium text-primary">Can I make changes to the design during construction?</span>
                        <i class="fa fa-plus text-secondary"></i>
                    </button>
                    <div class="faq-content hidden p-4 bg-white/50">
                        <p class="text-gray-700">While we aim to finalize all designs before construction begins, we understand that changes may be desired. Smaller modifications can usually be accommodated with minimal impact to schedule and budget. Significant changes after construction has started may require design revisions, new approvals, and can affect the project timeline and cost. We'll always discuss the implications of any changes with you before proceeding.</p>
                    </div>
                </div>
                
                <div class="border border-primary/30 rounded-lg overflow-hidden">
                    <button class="faq-toggle w-full p-4 text-left bg-white flex justify-between items-center">
                        <span class="text-lg font-medium text-primary">What warranty do you provide on your construction work?</span>
                        <i class="fa fa-plus text-secondary"></i>
                    </button>
                    <div class="faq-content hidden p-4 bg-white/50">
                        <p class="text-gray-700">We offer a comprehensive 5-year structural warranty and a 1-year workmanship warranty on all our construction projects. Critical systems like plumbing and electrical are covered for 2 years. Our warranty covers any defects in materials or workmanship. We also provide a detailed maintenance guide for your home and are available for consultation even after the warranty period expires to ensure your complete satisfaction.</p>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-12">
                <p class="text-gray-700 mb-4">Have more questions?</p>
                <a href="#contact" class="inline-block bg-primary hover:bg-darkblue text-white font-bold py-3 px-6 rounded-full transition duration-300">
                    Contact Us Now
                </a>
            </div>
        </div>
    </section> -->


<script src="assets/js/easy_background.js"></script>

<script>
    // Mobile menu toggle
    document.querySelector('.mobile-menu-button').addEventListener('click', function() {
        document.querySelector('.mobile-menu').classList.toggle('hidden');
    });

    // FAQ toggle functionality
    document.querySelectorAll('.faq-toggle').forEach(button => {
        button.addEventListener('click', () => {
            const faqContent = button.nextElementSibling;
            const icon = button.querySelector('i');

            // Toggle the content
            faqContent.classList.toggle('hidden');

            // Change the icon
            if (faqContent.classList.contains('hidden')) {
                icon.classList.remove('fa-minus');
                icon.classList.add('fa-plus');
            } else {
                icon.classList.remove('fa-plus');
                icon.classList.add('fa-minus');
            }
        });
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });

                // Close mobile menu if open
                if (!document.querySelector('.mobile-menu').classList.contains('hidden')) {
                    document.querySelector('.mobile-menu').classList.add('hidden');
                }
            }
        });
    });

    // Sticky header shadow on scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 50) {
            header.classList.add('shadow-xl');
        } else {
            header.classList.remove('shadow-xl');
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const imageSources = [
        "assets/img/residential/inter2.jpeg",
        "assets/img/residential/inter3.jpg",
        "assets/img/residential/inter4.jpg",
        "assets/img/residential/2012-08-03 11.43.41_1_11zon.jpg",
        "assets/img/residential/private_8_8_11zon.webp",
        "assets/img/residential/WhatsApp Image 2023-06-28 at 7.20.54 PM (1)_9_11zon.jpg"
    ];

    let currentIndex = 0;

    function openModal(element) {
        const imgSrc = element.querySelector('img').getAttribute('src');
        currentIndex = imageSources.indexOf(imgSrc);
        if (currentIndex === -1) {
            console.warn("Image not found in list:", imgSrc);
            currentIndex = 0;
        }
        showImage(currentIndex);
        document.getElementById('imageModal').classList.remove('hidden');
        document.getElementById('imageModal').classList.add('flex');
    }

    function closeModal() {
        document.getElementById('imageModal').classList.add('hidden');
        document.getElementById('imageModal').classList.remove('flex');
    }

    function showImage(index) {
        const modalImg = document.getElementById('modalImage');
        modalImg.setAttribute('src', imageSources[index]);
    }

    function prevImage() {
        currentIndex = (currentIndex - 1 + imageSources.length) % imageSources.length;
        showImage(currentIndex);
    }

    function nextImage() {
        currentIndex = (currentIndex + 1) % imageSources.length;
        showImage(currentIndex);
    }
</script>


<?php include('footer.php'); ?>