<?php
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer();
$mail->IsSMTP();

$name    = filter_var($_POST["name"], FILTER_SANITIZE_STRING);
$email   = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
$phone   = filter_var($_POST["phone"], FILTER_SANITIZE_STRING);
$message = filter_var($_POST["message"], FILTER_SANITIZE_STRING);

$num1  = filter_var($_POST["num1"], FILTER_SANITIZE_STRING);
$num2  = filter_var($_POST["num2"], FILTER_SANITIZE_STRING);
$total = filter_var($_POST["captcha"], FILTER_SANITIZE_STRING);

function captcha_validation($num1, $num2, $total) {
	global $error;
	if (intval($num1) + intval($num2) == intval($total)) {
		$error = null;
	} else {
		$error = "Captcha value is wrong.";
	}
	return $error;
}

$captcha_error = captcha_validation($num1, $num2, $total);

if ($captcha_error == null) {
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 587;
	$mail->SMTPAuth = true;
	$mail->Username = 'harsh.suryan10@gmail.com';
	$mail->Password = 'xuyy cvmz vryi rhhh'; // App password only
	$mail->SMTPSecure = 'tls';
	$mail->From = $email;
	$mail->FromName = $name;
	$mail->addAddress('harsh.suryan10@gmail.com', 'Builld Amaze');
	$mail->WordWrap = 50;
	$mail->isHTML(true);
	$mail->Subject = "The Builld Amaze Contact Form";
	$mail->Body = "Name: $name<br>Email: $email<br>Mobile: $phone<br>Message: $message";

	if ($mail->send()) {
		echo '<script>alert("Message Successfully Sent!!! Thank you.");window.location.assign("contact.php");</script>';
	} else {
		echo '<label class="text-danger">Message could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</label>';
	}
} else {
	echo '<script>alert("Captcha Value is Wrong!!!");window.location.assign("contact.php");</script>';
}
?>
