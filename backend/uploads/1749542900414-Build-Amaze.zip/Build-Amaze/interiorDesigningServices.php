<?php include('header.php'); ?>
<script src="https://cdn.tailwindcss.com"></script>
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'primary-blue': '#1E3A8A',
                    'secondary-blue': '#3B82F6',
                    'accent-yellow': '#F59E0B',
                    'light-yellow': '#FEF3C7',
                }
            }
        }
    }
</script>
<style>
  .header-top-info {
    display: flex !important;
    align-items: center !important;
  }
  .header-top-info.text-end {
    justify-content: flex-end !important;
  }
  .header-top-info.text-center {
    justify-content: center !important;
  }
  .header-top-info__image {
    padding-right: 0.5rem !important;
  }
</style>

<style>
    
    /* Custom animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .fadeInUp {
        animation: fadeInUp 0.8s ease-out forwards;
    }

    /* Custom hover effects */
    .service-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    }

    .gradient-highlight {
        background: #17263b;
    }

    /* Custom underline effect */
    .underline-effect {
        position: relative;
        display: inline-block;
    }

    .underline-effect:after {
        content: '';
        position: absolute;
        width: 100%;
        transform: scaleX(0);
        height: 3px;
        bottom: -5px;
        left: 0;
        background-color: #F59E0B;
        transform-origin: bottom right;
        transition: transform 0.3s ease-out;
    }

    .underline-effect:hover:after {
        transform: scaleX(1);
        transform-origin: bottom left;
    }

    /* Responsive hero height */
    @media (min-width: 1024px) {
        .hero-height {
            height: calc(100vh - 80px);
        }
    }
</style>
<!-- Hero Section -->
<div class="relative overflow-hidden gradient-highlight sm:mt-0 lg:mt-[80px]">
    <div class="container mx-auto px-4 py-16 text-center">
        <h1 class="text-4xl md:text-6xl font-bold text-white mb-6">
            <span class="block">Interior Designing</span>
            <span class="text-yellow-300">Services</span>
        </h1>
        <p class="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Crafting Spaces That Inspire and Function
        </p>
    </div>
    <div class="absolute bottom-0 left-0 right-0 h-2 bg-yellow-400"></div>
</div>

<!-- About Section -->
<!-- <section id="about" class="py-16 bg-lightyellow">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row items-center">
            <div class="md:w-1/2 mb-10 md:mb-0 md:pr-10">
                <div class="relative">
                    <img src="assets/img/interior/int1.jpg"
                        alt="Construction Team"
                        class="rounded-lg shadow-xl w-full">
                    <div class="absolute -bottom-6 -right-6  text-white p-6 rounded-lg shadow-lg max-w-xs" style="background-color: #17263b;">
                        <h3 class="font-bold text-xl mb-2 text-white">15+ Years Experience</h3>
                        <p class="text-sm">Trusted by homeowners across Bangalore</p>
                    </div>
                </div>
            </div>
            <div class="md:w-1/2">
                <h2 class="text-3xl font-bold  mb-6" style="color: #17263b;">About BuilldAmaze</h2>
                <p class="text-gray-700 mb-4">At Builld Amaze, we believe that exceptional interiors are the soul of any structure. Our Interior Designing Services go beyond aesthetics; we craft bespoke environments that perfectly blend beauty, functionality, and personal expression. </p>
                <p class="text-gray-700 mb-6">Whether it's a vibrant home, a dynamic office, or a welcoming commercial space, our award-winning designers transform mere rooms into captivating experiences that reflect your unique style and enhance your daily life.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <div class="flex items-start">
                        <i class="fa fa-check-circle text-secondary text-xl mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-bold " style="color: #17263b;">Quality Materials</h4>
                            <p class="text-gray-600 text-sm">Only the best materials for lasting durability</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <i class="fa fa-check-circle text-secondary text-xl mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-bold " style="color: #17263b;">Skilled Professionals</h4>
                            <p class="text-gray-600 text-sm">Highly trained and experienced craftsmen</p>
                        </div>
                    </div>
                </div>
                <a href="about.php" class="inline-flex items-center  font-bold hover:text-darkblue" style="color: #17263b;">
                    Learn More About Us
                    <i class="fa fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</section> -->

<!-- Services Section -->
<section id="services" class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16 fadeInUp">
            <h2 class="text-3xl md:text-4xl font-bold  mb-4" style="color: #17263b;">Our Holistic Approach to <span class="text-accent-yellow">Interior Design</span></h2>
            <p class="text-lg text-gray-600 max-w-3xl mx-auto">
                We understand that every client and every space is unique. Our process is collaborative, comprehensive, and tailored to bring your vision to life.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Service 1 -->
            <div class="service-card bg-white p-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105  hover:border-yellow-400 fadeInUp" style="animation-delay: 0.1s; border: 1px solid #17263b;">
                <div class="bg-light-yellow p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <i class="fas fa-lightbulb text-accent-yellow text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold  mb-3" style="color: #17263b;">Conceptualization & Visioning</h3>
                <p class="text-gray-600">
                    We develop a cohesive design concept through detailed consultations, mood boards, and ideation sessions that align perfectly with your aspirations.
                </p>
            </div>

            <!-- Service 2 -->
            <div class="service-card bg-white p-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105  hover:border-yellow-400 fadeInUp" style="animation-delay: 0.1s; border: 1px solid #17263b;">
                <div class="bg-light-yellow p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <i class="fas fa-ruler-combined text-accent-yellow text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold  mb-3" style="color: #17263b;">Space Planning & Optimization</h3>
                <p class="text-gray-600">
                    We create intelligent layouts that enhance flow, optimize natural light, and ensure ergonomic efficiency, making every space work smarter.
                </p>
            </div>

            <!-- Service 3 -->
            <div class="service-card bg-white p-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105  hover:border-yellow-400 fadeInUp" style="animation-delay: 0.1s; border: 1px solid #17263b;">
                <div class="bg-light-yellow p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <i class="fas fa-palette text-accent-yellow text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold  mb-3" style="color: #17263b;">Material & Finish Selection</h3>
                <p class="text-gray-600">
                    We guide you through curated selections of luxurious textures, sustainable materials, and sophisticated color palettes.
                </p>
            </div>

            <!-- Service 4 -->
            <div class="service-card bg-white p-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105  hover:border-yellow-400 fadeInUp" style="animation-delay: 0.1s; border: 1px solid #17263b;">
                <div class="bg-light-yellow p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <i class="fas fa-lightbulb text-accent-yellow text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold  mb-3" style="color: #17263b;">Lighting Design</h3>
                <p class="text-gray-600">
                    Comprehensive lighting schemes that create atmosphere, highlight features, and provide optimal illumination for every activity.
                </p>
            </div>

            <!-- Service 5 -->
            <div class="service-card bg-white p-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105  hover:border-yellow-400 fadeInUp" style="animation-delay: 0.1s; border: 1px solid #17263b;">
                <div class="bg-light-yellow p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <i class="fas fa-couch text-accent-yellow text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold  mb-3" style="color: #17263b;">Furniture & Fixture Curation</h3>
                <p class="text-gray-600">
                    Selecting or custom-designing furniture, fixtures, and décor items that complement your design while offering comfort and individuality.
                </p>
            </div>

            <!-- Service 6 -->
            <div class="service-card bg-white p-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105  hover:border-yellow-400 fadeInUp" style="animation-delay: 0.1s; border: 1px solid #17263b;">      
                <div class="bg-light-yellow p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                    <i class="fas fa-project-diagram text-accent-yellow text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold  mb-3" style="color: #17263b;">Project Coordination</h3>
                <p class="text-gray-600">
                    We manage the entire implementation process, ensuring meticulous execution, quality craftsmanship, and timely delivery.
                </p>
            </div>
        </div>
    </div>
</section>



<!-- Specializations Section -->
<section id="specializations" class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16 fadeInUp">
            <h2 class="text-3xl md:text-4xl font-bold  mb-4" style="color: #17263b;">Our <span class="text-accent-yellow">Specializations</span></h2>
            <p class="text-lg text-gray-600 max-w-3xl mx-auto">
                We design spaces that resonate with your personal style, brand identity, and functional requirements.
            </p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Residential -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden border-1 border-black fadeInUp">
                <div class="h-64 overflow-hidden">
                    <img src="assets/img/hero-slider/3.jpg"
                        alt="Residential Interior Design"
                        class="w-full h-full object-cover transition duration-500 hover:scale-110">
                </div>
                <div class="p-8">
                    <h3 class="text-2xl font-bold text-primary-blue mb-3">Residential Interior Design</h3>
                    <p class="text-gray-600 mb-4">
                        Crafting personalized sanctuaries – from contemporary apartments and sprawling villas to cozy family homes. We design living rooms, bedrooms, kitchens, bathrooms, and outdoor spaces that resonate with your personal style and comfort.
                    </p>
                    <ul class="space-y-3">
                        <li class="flex items-center">
                            <div class="bg-light-yellow p-1 rounded-full mr-3">
                                <i class="fas fa-check text-accent-yellow text-sm"></i>
                            </div>
                            <span>Custom home interiors</span>
                        </li>
                        <li class="flex items-center">
                            <div class="bg-light-yellow p-1 rounded-full mr-3">
                                <i class="fas fa-check text-accent-yellow text-sm"></i>
                            </div>
                            <span>Kitchen & bathroom redesigns</span>
                        </li>
                        <li class="flex items-center">
                            <div class="bg-light-yellow p-1 rounded-full mr-3">
                                <i class="fas fa-check text-accent-yellow text-sm"></i>
                            </div>
                            <span>Whole-house transformations</span>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Commercial -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden fadeInUp border-1 border-black" style="animation-delay: 0.2s;">
                <div class="h-64 overflow-hidden">
                    <img src="assets/img/hero-slider/1.jpg"
                        alt="Commercial Interior Design"
                        class="w-full h-full object-cover transition duration-500 hover:scale-110">
                </div>
                <div class="p-8">
                    <h3 class="text-2xl font-bold text-primary-blue mb-3">Commercial Interior Design</h3>
                    <p class="text-gray-600 mb-4">
                        Developing impactful and functional interiors for offices, retail stores, restaurants, showrooms, and hospitality venues. We focus on enhancing brand presence, optimizing workflow, and creating inviting environments for clients and employees.
                    </p>
                    <ul class="space-y-3">
                        <li class="flex items-center">
                            <div class="bg-light-yellow p-1 rounded-full mr-3">
                                <i class="fas fa-check text-accent-yellow text-sm"></i>
                            </div>
                            <span>Office spaces & coworking environments</span>
                        </li>
                        <li class="flex items-center">
                            <div class="bg-light-yellow p-1 rounded-full mr-3">
                                <i class="fas fa-check text-accent-yellow text-sm"></i>
                            </div>
                            <span>Retail stores & showrooms</span>
                        </li>
                        <li class="flex items-center">
                            <div class="bg-light-yellow p-1 rounded-full mr-3">
                                <i class="fas fa-check text-accent-yellow text-sm"></i>
                            </div>
                            <span>Restaurants & hospitality venues</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Renovation -->
        <div class="mt-8 bg-white rounded-xl shadow-md overflow-hidden fadeInUp border-1 border-black" style="animation-delay: 0.4s;">
            <div class="flex flex-col md:flex-row">
                <div class="md:w-1/3 h-64 md:h-auto overflow-hidden">
                    <img src="assets/img/hero-slider/2.jpg"
                        alt="Renovation & Remodeling"
                        class="w-full h-full object-cover">
                </div>
                <div class="p-8 md:w-2/3">
                    <h3 class="text-2xl font-bold text-primary-blue mb-3">Renovation & Remodeling</h3>
                    <p class="text-gray-600 mb-4">
                        Transforming existing spaces into modern, functional, and aesthetically refreshed environments, breathing new life into older properties. We specialize in structural changes, spatial reconfigurations, and complete home makeovers.
                    </p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="bg-primary-blue bg-opacity-10 p-4 rounded-lg border border-primary-blue border-opacity-20">
                            <h4 class="font-bold text-primary-blue mb-2">Space Reconfigurations</h4>
                            <p class="text-sm text-gray-600">Optimizing existing layouts for better flow and functionality</p>
                        </div>
                        <div class="bg-primary-blue bg-opacity-10 p-4 rounded-lg border border-primary-blue border-opacity-20">
                            <h4 class="font-bold text-primary-blue mb-2">Materials Refresh</h4>
                            <p class="text-sm text-gray-600">Updating surfaces, fixtures, and finishes for a modern look</p>
                        </div>
                        <div class="bg-primary-blue bg-opacity-10 p-4 rounded-lg border border-primary-blue border-opacity-20">
                            <h4 class="font-bold text-primary-blue mb-2">Structural Changes</h4>
                            <p class="text-sm text-gray-600">Removing or adding walls, altering room dimensions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose Us Section -->
<section class="py-16 bg-lightyellow">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold mb-4" style="color: #17263b;">
                Why Choose Builld Amaze for Your Interior Design Needs?
            </h2>
            <div class="w-24 h-1 bg-secondary mx-auto"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Card 1 -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border-2 border-[#17263b] transform transition-transform duration-300 hover:scale-105 hover:shadow-xl hover:border-yellow-400">
                <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-[#17263b]">
                    <i class="fas fa-project-diagram text-3xl text-white transition-transform duration-500 group-hover:animate-spin"></i>
                </div>
                <h3 class="text-xl font-bold mb-4" style="color: #17263b;">Integrated Approach</h3>
                <p class="text-gray-600">Our interior design team collaborates seamlessly with architects and builders for a holistic project delivery.</p>
            </div>

            <!-- Card 2 -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border-2 border-[#17263b] transform transition-transform duration-300 hover:scale-105 hover:shadow-xl hover:border-yellow-400">
                <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-[#17263b]">
                    <i class="fas fa-people-group text-3xl text-white transition-transform duration-500 group-hover:animate-pulse"></i>
                </div>
                <h3 class="text-xl font-bold mb-4" style="color: #17263b;">Expert Design Team</h3>
                <p class="text-gray-600">Renowned for creativity and attention to detail, our designers bring visions to life beautifully.</p>
            </div>

            <!-- Card 3 -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border-2 border-[#17263b] transform transition-transform duration-300 hover:scale-105 hover:shadow-xl hover:border-yellow-400">
                <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-[#17263b]">
                    <i class="fas fa-award text-3xl text-white transition-transform duration-500 group-hover:animate-spin"></i>
                </div>
                <h3 class="text-xl font-bold mb-4" style="color: #17263b;">Uncompromising Quality</h3>
                <p class="text-gray-600">We use premium materials and skilled artisans to ensure excellence from concept to execution.</p>
            </div>

            <!-- Card 4 -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border-2 border-[#17263b] transform transition-transform duration-300 hover:scale-105 hover:shadow-xl hover:border-yellow-400">
                <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-[#17263b]">
                    <i class="fas fa-handshake text-3xl text-white transition-transform duration-500 group-hover:animate-pulse"></i>
                </div>
                <h3 class="text-xl font-bold mb-4" style="color: #17263b;">Client-Centric Collaboration</h3>
                <p class="text-gray-600">We prioritize your preferences and ideas in every step for a truly collaborative experience.</p>
            </div>

            <!-- Card 5 -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border-2 border-[#17263b] transform transition-transform duration-300 hover:scale-105 hover:shadow-xl hover:border-yellow-400">
                <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-[#17263b]">
                    <i class="fas fa-business-time text-3xl text-white transition-transform duration-500 group-hover:animate-spin"></i>
                </div>
                <h3 class="text-xl font-bold mb-4" style="color: #17263b;">Timely & Budget-Conscious</h3>
                <p class="text-gray-600">We ensure timely delivery within budgets, providing a smooth and reliable experience.</p>
            </div>

            <!-- Card 6 -->
            <div class="group bg-white p-8 rounded-lg shadow-md text-center border-2 border-[#17263b] transform transition-transform duration-300 hover:scale-105 hover:shadow-xl hover:border-yellow-400">
                <div class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-[#17263b]">
                    <i class="fas fa-magic text-3xl text-white transition-transform duration-500 group-hover:animate-pulse"></i>
                </div>
                <h3 class="text-xl font-bold mb-4" style="color: #17263b;">Transformative Results</h3>
                <p class="text-gray-600">We design spaces that uplift well-being, aesthetics, and the functionality of daily living.</p>
            </div>
        </div>
    </div>
</section>



<!-- Projects Gallery -->
<section id="projects" class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold mb-4" style="color: #17263b;">Our Recent Projects</h2>
            <div class="w-24 h-1 bg-secondary mx-auto"></div>
            <p class="text-gray-600 mt-4 max-w-3xl mx-auto">Browse through our portfolio of exceptional commercial projects in Bangalore.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/interior/int1.jpg"
                    alt="Modern Villa Project"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/hero-slider/3.jpg"
                    alt="Contemporary Apartment"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/hero-slider/2.jpg"
                    alt="Heritage Bungalow"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/interior/int4.jpg"
                    alt="Luxury Penthouse"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/interior/DSC_1707_4_11zon.jpg"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/hero-slider/1.jpg"
                    alt="Gated Community"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<div id="imageModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black bg-opacity-70">
    <div class="relative bg-white p-4 rounded-lg shadow-lg max-w-2xl w-full max-h-[65vh] overflow-auto">
        <button onclick="closeModal()" class="absolute top-2 right-1 text-black text-6xl font-bold">&times;</button>

        <!-- Left Arrow -->
        <button onclick="prevImage()" class="absolute left-1 top-1/2 transform -translate-y-1/2 text-4xl text-gray-600 hover:text-black z-10">
            &#10094;
        </button>

        <!-- Right Arrow -->
        <button onclick="nextImage()" class="absolute right-1 top-1/2 transform -translate-y-1/2 text-4xl text-gray-600 hover:text-black z-10">
            &#10095;
        </button>

        <img id="modalImage" src="" alt="Project Image" class="w-full h-auto rounded">
    </div>
</div>
<style>
    #imageModal button {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0 10px;
}

</style>
<!-- CTA Section -->
<section class="py-16  text-white" style="background-color: #17263b;">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6 text-yellow-500">Begin Your Home Building Journey with Builld Amaze</h2>
        <p class="text-xl mb-8 max-w-2xl mx-auto text-white">Imagine stepping into a home that perfectly encapsulates your vision, built with unparalleled craftsmanship and attention to every detail. With Builld Amaze, this dream is within reach.</p>
      
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const imageSources = [
        "assets/img/interior/int1.jpg",
        "assets/img/hero-slider/3.jpg",
        "assets/img/hero-slider/2.jpg",
        "assets/img/interior/int4.jpg",
        "assets/img/interior/DSC_1707_4_11zon.jpg",
        "assets/img/hero-slider/1.jpg"
    ];

    let currentIndex = 0;

    function openModal(element) {
        const imgSrc = element.querySelector('img').getAttribute('src');
        currentIndex = imageSources.indexOf(imgSrc);
        if (currentIndex === -1) {
            console.warn("Image not found in imageSources:", imgSrc);
            currentIndex = 0;
        }
        showImage(currentIndex);
        document.getElementById('imageModal').classList.remove('hidden');
        document.getElementById('imageModal').classList.add('flex');
    }

    function closeModal() {
        document.getElementById('imageModal').classList.add('hidden');
        document.getElementById('imageModal').classList.remove('flex');
    }

    function showImage(index) {
        const modalImg = document.getElementById('modalImage');
        modalImg.setAttribute('src', imageSources[index]);
    }

    function prevImage() {
        currentIndex = (currentIndex - 1 + imageSources.length) % imageSources.length;
        showImage(currentIndex);
    }

    function nextImage() {
        currentIndex = (currentIndex + 1) % imageSources.length;
        showImage(currentIndex);
    }
</script>

<?php include('footer.php'); ?>