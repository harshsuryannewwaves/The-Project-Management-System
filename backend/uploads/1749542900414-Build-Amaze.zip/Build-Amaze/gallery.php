<?php include('header.php'); ?>
<style>
    .header-top-info {
        display: flex !important;
        align-items: center !important;
    }

    .header-top-info.text-end {
        justify-content: flex-end !important;
    }

    .header-top-info.text-center {
        justify-content: center !important;
    }

    .header-top-info__image {
        padding-right: 0.5rem !important;
    }
</style>
<script src="https://cdn.tailwindcss.com"></script>
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: {
                        100: '#dbeafe',
                        200: '#bfdbfe',
                        300: '#93c5fd',
                        400: '#60a5fa',
                        500: '#3b82f6',
                        600: '#2563eb',
                        700: '#1d4ed8',
                    },
                    secondary: {
                        100: '#fef9c3',
                        200: '#fef08a',
                        300: '#fde047',
                        400: '#facc15',
                        500: '#eab308',
                        600: '#ca8a04',
                        700: '#a16207',
                    }
                }
            }
        }
    }
</script>
<style>
    .gallery-item {
        transition: all 0.3s ease;
    }

    .gallery-masonry {
        column-count: 1;
        column-gap: 1rem;
    }

    @media (min-width: 768px) {
        .gallery-masonry {
            column-count: 2;
        }
    }

    @media (min-width: 1024px) {
        .gallery-masonry {
            column-count: 3;
        }
    }

    @media (min-width: 1280px) {
        .gallery-masonry {
            column-count: 3;
        }
    }

    .gallery-masonry .item {
        break-inside: avoid;
        margin-bottom: 1rem;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        border-radius: 12px;
    }

    .gallery-masonry .item img {
        transition: transform 0.4s ease;
        width: 100%;
        display: block;
    }

    .gallery-masonry .item:hover img {
        transform: scale(1.05);
    }

    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.7) 0%, transparent 50%);
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        padding: 1.5rem;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .gallery-masonry .item:hover .overlay {
        opacity: 1;
    }

    .modal-content-container {
        animation: modalFadeIn 0.3s ease-out;
    }

    @keyframes modalFadeIn {
        from {
            opacity: 0;
            transform: scale(0.9);
        }

        to {
            opacity: 1;
            transform: scale(1);
        }
    }
</style>
<style>
    @media only screen and (max-width: 767px) {
        #hero-section-about {
            margin-top: 0px;
        }
    }
</style>
<style>
    .project-area .row>div {
        /* display: flex;
  justify-content: center;
  align-items: center; */
        height: 100%;
        margin-bottom: 20px;
        /* height: 550px; */
        /* Match iframe height */
        overflow: hidden;
    }

    .project-area .row img {
        height: 100%;
        width: auto;
        object-fit: fill;
    }

    .project-area .row iframe {
        height: 350px;
    }

    @media (max-width: 768px) {

        /* Ensure each tab-pane has enough spacing */
        .tab-pane {
            margin-bottom: 40px;
        }

        /* Ensure images and iframes are responsive and do not collapse */
        .tab-pane .img-fluid,
        .tab-pane iframe {
            width: 100% !important;
            height: auto;
            display: block;
            margin-bottom: 15px;
        }

        /* Add spacing under project section to prevent overlap */
        .project-area {
            padding-bottom: 0px;
            /* height: 100%; */
        }

        .project-area .row>div {
            height: 100%;
        }

        /* Optional: Ensure testimonial area is pushed below */
        .testimonial-area {
            margin-top: 20px;
        }
    }
</style>
<!-- Hero Section -->
<header class="py-8  text-white text-center shadow-lg sm:mt-0 lg:mt-[5rem]" style="background-color: #17263b;">
    <h1 class="text-4xl md:text-5xl font-bold text-white">Gallery</h1>
    <!-- <p class="mt-2 text-lg md:text-xl opacity-90">Exploring design excellence in residential, commercial, interiors, and unique spaces</p> -->
</header>

<!--====================  project area ====================-->
<div class="project-area ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-6 ">
                <!-- Section Title -->
                <div class="section-title text-center  mx-auto">
                    <!-- <h3 class="section-title__title">Our Projects</h3> -->
                </div>

                <!-- Tabs -->
                <ul class="nav nav-pills custom-tabs justify-content-center mb-4" id="projectTabs" role="tablist" style="margin-top:20px">
                    <li class="nav-item">
                        <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab">
                            <i class="fas fa-layer-group me-2"></i>ALL
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" id="video-tab" data-bs-toggle="tab" data-bs-target="#video" type="button" role="tab">
                            <i class="fas fa-video me-2"></i>Videos
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" id="residential-tab" data-bs-toggle="tab" data-bs-target="#residential" type="button" role="tab">
                            <i class="fas fa-home me-2"></i>Residential
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" id="commercial-tab" data-bs-toggle="tab" data-bs-target="#commercial" type="button" role="tab">
                            <i class="fas fa-building me-2"></i>Commercial
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" id="interior-tab" data-bs-toggle="tab" data-bs-target="#interior" type="button" role="tab">
                            <i class="fas fa-couch me-2"></i>Interiors
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" id="others-tab" data-bs-toggle="tab" data-bs-target="#others" type="button" role="tab">
                            <i class="fas fa-puzzle-piece me-2"></i>Unique Projects
                        </button>
                    </li>
                </ul>

                <style>
                    .custom-tabs .nav-link {
                        border-radius: 30px;
                        margin: 5px;
                        padding: 10px 20px;
                        font-weight: 600;
                        color: white;
                        background-color: #17263b;
                        border: none;
                        transition: all 0.3s ease-in-out;
                    }

                    .custom-tabs .nav-link:hover {
                        background-color: #bae6fd;
                        color: #facc15;
                    }

                    .custom-tabs .nav-link.active {
                        background-color: #0ea5e9;
                        color: #17263b;
                        ;
                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                    }


                   
                </style>



                <!-- Tab Content -->
                <div class="tab-content" id="projectTabsContent">
                    <!-- All Tab -->
                    <div class="tab-pane fade show active" id="all" role="tabpanel">
                        <div class="row">
                            <div class="col-12 col-md-4 video-wrapper">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    src="https://www.youtube.com/embed/nNPJEwTIgdw?showinfo=0"
                                    title="YouTube video player"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen>
                                </iframe>
                            </div>
                            <div class="col-12 col-md-4 video-wrapper">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    src="https://www.youtube.com/embed/qNZA3gq_0WU?showinfo=0"
                                    title="YouTube video player"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen>
                                </iframe>
                            </div>
                            <div class="col-12 col-md-4 ">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    src="https://www.youtube.com/embed/wIxd2d_QoKQ"
                                    title="YouTube video player"
                                    frameborder="0"
                                    allowfullscreen
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture">
                                </iframe>
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/residential/2012-08-03 11.43.41_1_11zon.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/residential/inter3.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/residential/WhatsApp Image 2023-06-28 at 7.20.54 PM (1)_9_11zon.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/commercial/comm1.jpeg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/commercial/comm2.jpeg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/commercial/comm3.jpeg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/interior/int1.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/interior/int2.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/interior/int3.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/unique/2014-01-31 11.40.55_1_11zon.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/unique/unique2.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/unique/unique3.jpg" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>
                    <!-- Residential Tab -->
                    <div class="tab-pane fade show " id="residential" role="tabpanel">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <img src="assets/img/residential/2012-08-03 11.43.41_1_11zon.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/residential/inter3.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/residential/WhatsApp Image 2023-06-28 at 7.20.54 PM (1)_9_11zon.jpg" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>

                    <!-- Commercial Tab -->
                    <div class="tab-pane fade" id="commercial" role="tabpanel">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <img src="assets/img/commercial/comm1.jpeg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/commercial/comm2.jpeg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/commercial/comm3.jpeg" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>

                    <!-- Interior Tab -->
                    <div class="tab-pane fade" id="interior" role="tabpanel">
                        <div class="row">

                            <div class="col-12 col-md-4">
                                <img src="assets/img/interior/int1.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/interior/int2.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/interior/int3.jpg" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>

                    <!-- Others Tab -->
                    <div class="tab-pane fade" id="others" role="tabpanel">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <img src="assets/img/unique/2014-01-31 11.40.55_1_11zon.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/unique/unique2.jpg" class="img-fluid" alt="">
                            </div>
                            <div class="col-12 col-md-4">
                                <img src="assets/img/unique/unique3.jpg" class="img-fluid" alt="">
                            </div>
                        </div>
                    </div>
                    <!-- Video Tab -->
                    <div class="tab-pane fade" id="video" role="tabpanel">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    src="https://www.youtube.com/embed/nNPJEwTIgdw?showinfo=0"
                                    title="YouTube video player"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen>
                                </iframe>
                            </div>
                            <div class="col-12 col-md-4">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    src="https://www.youtube.com/embed/qNZA3gq_0WU?showinfo=0"
                                    title="YouTube video player"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen>
                                </iframe>
                            </div>
                            <div class="col-12 col-md-4">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    src="https://www.youtube.com/embed/wIxd2d_QoKQ"
                                    title="YouTube video player"
                                    frameborder="0"
                                    allowfullscreen
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture">
                                </iframe>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.tab-content -->
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>
<!-- Modal -->
<div id="imageModal" class="mt-4 fixed inset-0 z-50 hidden items-center justify-center bg-black bg-opacity-80">
    <div class="relative bg-white rounded-lg shadow-lg max-w-3xl w-full p-4">
        <!-- Close Button -->
        <button onclick="closeModal()" class="absolute top-2 right-2 text-black text-6xl font-bold">&times;</button>

        <!-- Left Arrow -->
        <button onclick="prevImage()" class="absolute left-2 top-1/2 transform -translate-y-1/2 text-4xl text-black font-bold z-10">
            &#10094;
        </button>

        <!-- Right Arrow -->
        <button onclick="nextImage()" class="absolute right-2 top-1/2 transform -translate-y-1/2 text-4xl text-black font-bold z-10">
            &#10095;
        </button>

        <!-- Image Preview -->
        <img id="modalImage" src="" class="w-full h-auto rounded" alt="Preview">
    </div>
</div>
<script>
    let imageList = [];
    let currentIndex = 0;

    // Collect all images from tabs
    document.addEventListener('DOMContentLoaded', function() {
        const images = document.querySelectorAll('#projectTabsContent img');
        images.forEach((img, index) => {
            imageList.push(img.src);
            img.setAttribute('data-index', index);
            img.style.cursor = 'pointer';
            img.addEventListener('click', () => openModal(index));
        });
    });

    function openModal(index) {
        currentIndex = index;
        showImage(currentIndex);
        const modal = document.getElementById('imageModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeModal() {
        const modal = document.getElementById('imageModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    function showImage(index) {
        const modalImg = document.getElementById('modalImage');
        modalImg.src = imageList[index];
    }

    function prevImage() {
        currentIndex = (currentIndex - 1 + imageList.length) % imageList.length;
        showImage(currentIndex);
    }

    function nextImage() {
        currentIndex = (currentIndex + 1) % imageList.length;
        showImage(currentIndex);
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!--====================  End of project area  ====================-->