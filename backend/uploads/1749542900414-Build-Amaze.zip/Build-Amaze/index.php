<?php include('header.php'); ?>
<!-- Bootstrap CSS -->

<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> -->
<style>
    .text-left {
        text-align: left;
    }

    .ct {
        height: 95.8vh;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;

    }

    .slider-bg {
        height: 600px;
        /* Set your desired fixed height */
        position: relative;
        overflow: hidden;
        background-size: cover;
        background-position: center;
    }

    .custom-margin {
        margin-top: 0;
    }



    @media (min-width: 768px) {
        .custom-margin {
            margin-top: 82px;
        }
    }

    @media (max-width: 767.98px) {

        .fun-fact-wrapper {
            /* padding: 40px 20px; */
            background-size: cover;
            background-position: center;
        }

        .fun-fact-inner {
            padding: 40px 20px;
            background-size: cover;
            background-position: center;
        }

        .fun-fact-content-wrapper {
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .single-fun-fact__number {
            font-size: 36px;
        }

        .single-fun-fact__text {
            font-size: 16px;
        }
    }

    @media (max-width: 767.98px) {
        .tab-content .row>div {
            margin-bottom: 20px;
        }

        iframe {
            max-width: 100%;
            height: auto;
        }

        img.img-fluid {
            max-width: 100%;
            height: auto;
            display: block;
        }
    }


    /* .project-area .row {
  display: flex;
  flex-wrap: wrap;
} */

    .project-area .row>div {
        /* display: flex;
  justify-content: center;
  align-items: center; */
        height: 100%;
        margin-bottom: 20px;
        /* height: 550px; */
        /* Match iframe height */
        overflow: hidden;
    }

    .project-area .row img {
        height: 100%;
        width: auto;
        object-fit: fill;
    }

    .project-area .row iframe {
        height: 350px;
    }

    @media (max-width: 768px) {

        /* Ensure each tab-pane has enough spacing */
        .tab-pane {
            margin-bottom: 40px;
        }

        /* Ensure images and iframes are responsive and do not collapse */
        .tab-pane .img-fluid,
        .tab-pane iframe {
            width: 100% !important;
            height: auto;
            display: block;
            margin-bottom: 15px;
        }

        /* Add spacing under project section to prevent overlap */
        .project-area {
            padding-bottom: 0px;
            height: 100%;
        }

        .project-area .row>div {
            height: 100%;
        }

        /* Optional: Ensure testimonial area is pushed below */
        .testimonial-area {
            margin-top: 20px;
        }
    }
</style>
<style>
    .pbg1 {
        padding: 3%;
        text-align: center;
        background-color: rgb(72 171 213);
        margin-right: 0;
        margin-left: 0;
    }

    @media(max-width:768px) {
        .d-sm-none {
            display: none !important;
        }

        .pbg {

            padding: 28px 30px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 9px;
        }

        .pbg1 {
            padding: 3%;
            text-align: center;
            background-color: rgb(72 171 213);
            margin-right: 0;
            margin-left: 0;
        }

        .accordion-item {
            border: none !important;
        }

        .accordion-button::after {
            content: "" !important;
        }
    }

    @media(max-width:768px) {
        #slider figure {
            position: relative;
            width: 500%;
            margin: 0;
            left: 0;
            animation: 20s slider infinite;
            height: 248px;
        }

        #slider figure img {
            height: 245px !important;
        }

        .enq_form {
            /*   background: black;  */
            padding: 7%;
            padding-bottom: 18%;
            padding-top: 0%;
        }

        .slider_figure {
            padding: 0 !important;
        }
    }

    .video-wrapper {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .video-wrapper iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 0;
    }

    @media (max-width: 767.98px) {
        .feature-content-image iframe {
            height: 50vh;
            /* or 100vh if you want full viewport height */
            width: 100%;
        }

        /* Optional: remove margins/padding if needed for tighter spacing */
        .feature-content-image {
            padding: 0;
            margin: 0 auto;
            min-height: 450px;
        }
    }

    /* Mobile responsiveness */
    @media only screen and (max-width: 767px) {
        .section-title h3.section-title__sub {
            font-size: 35px;
            padding: 0 15px;
        }

        .service-grid-item {
            padding: 15px;
            margin: 0 10px;
        }

        .service-grid-item__content .title a {
            font-size: 18px;
        }

        .service-grid-item__content p {
            font-size: 14px;
        }

        .service-grid-item img {

            width: 50px;
            height: 50px;
        }

        .service-section {
            padding: 40px 0;
            margin-top: 0px !important;
        }

        .testimonial-area .section-title {
            margin-left: 0px !important;
        }
    }
</style>
<style>
    .testimonial-area {
        background-color: #f9fafb;
        padding: 60px 20px;
        position: relative;
    }

    .section-title {
        margin-bottom: 40px;
    }

    .section-title__sub {
        font-size: 32px;
        font-weight: bold;
        color: #1e3a8a;
        /* Deep Blue */
        position: relative;
        display: inline-block;
        padding-bottom: 8px;
    }

    .section-title__sub::after {
        content: "";
        width: 60px;
        height: 4px;
        background-color: #facc15;
        /* Yellow */
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        border-radius: 2px;
    }

    .testimonial-slider {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 30px;
    }

    .single-testimonial {
        background-color: #ffffff;
        border-left: 6px solid #facc15;
        /* Yellow border */
        border-radius: 10px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
        padding: 30px 20px;
        transition: transform 0.3s ease;
    }

    .single-testimonial:hover {
        transform: translateY(-6px);
    }

    .single-testimonial__text {
        font-size: 16px;
        color: #1e293b;
        /* Slate text */
        line-height: 1.6;
        margin-bottom: 20px;
        text-align: left;
    }

    .single-testimonial__author {
        font-weight: bold;
        color: #1e3a8a;
        font-size: 18px;
        margin-bottom: 2px;
    }

    .single-testimonial__author-des {
        font-size: 14px;
        color: #64748b;
        /* Muted gray */
    }

    .service-grid-item {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .service-grid-item:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 15px 40px rgba(0, 51, 102, 0.15);
    }

    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        cursor: pointer;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.25);
    }

    .benefit-list {
        padding-left: 20px;
        font-size: 16px;
        line-height: 1.8;
        font-weight: 500;
        /* Slight boldness for normal text */
        color: #333;
    }

    .benefit-list strong {
        font-weight: 700;
        /* Full bold for key phrases */
        color: #000;
    }

    .testimonial-slider {
        display: flex;
        overflow-x: auto;
        scroll-behavior: smooth;
        scroll-snap-type: x mandatory;
        -webkit-overflow-scrolling: touch;
        /* smooth scrolling on iOS */
        gap: 20px;
        scrollbar-width: none;
        /* Firefox */
    }

    .testimonial-slider::-webkit-scrollbar {
        display: none;
        /* Chrome, Safari, Opera */
    }

    .single-testimonial {
        flex: 0 0 100%;
        /* take full container width */
        scroll-snap-align: start;
        box-sizing: border-box;
        padding: 20px;
        background: #f9f9f9;
        /* or any bg you want */
        border-radius: 10px;
        /* optional shadow */
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    @media (max-width: 768px) {
        #slider-hero-section .slider-bg {
            height: 50vh !important;
        }
       .testimonial-card {
        flex: 0 0 70.3333%;
       }
    }
</style>

<div id="slider-hero-section" class="row align-items-center row-25 custom-margin">
    <div class="slider-bg ct position-relative" style="position: relative; height: 90vh; display: flex; align-items: center; background-size: cover; background-position: center; overflow: hidden;">

        <!-- Dark Blue Overlay -->
        <!-- <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.8); z-index: 1;"></div> -->

        <div class="row position-relative" style="z-index: 2; width: 100%;">
            <div class="row enq_form" style="width: 100%;">
                <div class="container" style="max-width: 1200px; margin: 0 auto;">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- <div class="slider-text pbg" style="
                                color: white; 
                                padding: 40px 30px; 
                                text-align: left; 
                                background: rgba(255, 255, 255, 0); 
                                border-left: 5px solid #facc15; 
                                border-radius: 10px;
                                max-width: 700px;
                            ">
                                <h2 style="margin-bottom: 10px; font-size: 36px; color: #facc15; font-weight: bold;">
                                    Innovative Homes for Modern Living.
                                </h2>
                                <h3 style="margin-bottom: 10px; font-size: 28px; color: #ffffff;">
                                    Your Vision, Our Foundation.
                                </h3>
                                <h4 style="font-size: 20px; color: #cbd5e1;">
                                    Built on Trust. Crafted for Life.
                                </h4>
                            </div> -->
                        </div>
                        <div class="col-md-4 d-none d-md-block d-lg-block"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container">




    <!--====================  about area ====================-->
    <div class="about-area space__bottom--r120" style="margin-top: 150px;">
        <div class="container">
            <div class="row align-items-stretch row-25" style="min-height: 100%;">
                <div class="col-md-6 d-flex align-items-stretch">
                    <div class="about-image w-100 d-flex">
                        <div class="video-wrapper w-100">
                            <iframe
                                width="100%"
                                height="550"
                                src="https://www.youtube.com/embed/wIxd2d_QoKQ"
                                title="YouTube video player"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen>
                            </iframe>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="about-content">
                        <!-- section title -->
                        <div class="section-title space__bottom--25">
                            <h3 class="section-title__sub" style="font-weight: 900;color: #17263b;">About Builld Amaze</h3>
                            <h2 class="section-title__title">Crafting Your Dream Home</h2>
                        </div>
                        <p class="about-content__text space__bottom--20" style="font-size: 15px; font-weight: 600;">
                            At Builld Amaze, we don't just construct buildings; we bring visions to life. Our founder's enduring foresight laid the groundwork for a company built on innovation, knowledge, and a deep understanding of what truly matters to our clients.
                        </p>
                        <p class="about-content__text space__bottom--20" style="font-size: 15px; font-weight: 600;">
                            As a Trusted Construction Company, we are renowned for our meticulous execution and unwavering commitment to quality. But we offer much more. Our expert Architectural Designers transform your aspirations into stunning, functional blueprints, while our bespoke Interior Solutions ensure every corner of your dream home reflects your unique style and comfort.
                        </p>
                        <p class="about-content__text space__bottom--20" style="font-size: 15px; font-weight: 600;">
                            We are bold in our approach, constantly seeking purposeful outcomes and common interests with our clients. This is how we consistently deliver on our promise: to builld amaze for your home.<br>

                        </p>
                        <a href="about.php" class="default-btn">Read more</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of about area  ====================-->
    <!--====================  feature area ====================-->
    <div class="feature-area space__bottom--r120">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 order-2 order-lg-1">
                    <div class="feature-content-wrapper space__bottom--m35">
                        <div class="section-title space__bottom--25">
                            <h2 class="section-title__title" style="font-weight: 900;">Why Choose Us?</h2>
                        </div>
                        <ul style="padding-left: 20px; font-size: 18px; line-height: 1.8;">
                            <li><strong>Beyond Expectations:</strong> We consistently go the extra mile to ensure your project isn't just completed, but perfected.</li>
                            <li><strong>On-Time Delivery:</strong> Your dream home, delivered precisely when promised, without compromising on quality.</li>
                            <li><strong>Premium Materials:</strong> We build with integrity, using only the highest quality materials for lasting beauty and durability.</li>
                            <li><strong>Smart & Sustainable Budgets:</strong> Achieve your vision with plans that are not just friendly to your wallet, but also thoughtfully optimized.</li>
                            <li><strong>Master Craftsmanship:</strong> Our highly skilled workforce, at every level, brings unparalleled expertise and precision to your project.</li>
                            <li><strong>Complete Transparency:</strong> Experience peace of mind with clear communication and full visibility throughout the entire process.</li>
                            <li><strong>Cutting-Edge Innovation:</strong> We integrate the latest technology and smart strategies to deliver superior results and modern efficiency.</li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-6 space__bottom__md--40 space__bottom__lm--40 order-1 order-lg-2">
                    <!-- feature content image -->
                    <div class="feature-content-image" style="text-align: center;">
                        <iframe
                            width="100%"
                            height="550"
                            src="https://www.youtube.com/embed/qNZA3gq_0WU?showinfo=0"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--====================  End of feature area  ====================-->
    <!--====================  feature area1 ====================-->
    <div class="feature-area space__bottom--r120">
        <div class="container">
            <div class="row">
                <!-- YouTube Video on Left -->
                <div class="col-lg-6 space__bottom__md--40 space__bottom__lm--40 order-1 order-lg-1">
                    <div class="feature-content-image" style="text-align: center;">
                        <iframe
                            width="100%"
                            height="550"
                            src="https://www.youtube.com/embed/nNPJEwTIgdw?showinfo=0"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>

                <!-- Text Content on Right -->
                <div class="col-lg-6 order-2 order-lg-2">
                    <div class="feature-content-wrapper space__bottom--m35">
                        <div class="section-title " style="margin-bottom: 10px;">
                            <h2 class="section-title__title">Building Tomorrow's Dreams, Today.</h2>
                        </div>
                        <p style="font-size: 16px; line-height: 1.8;font-weight: 600;">
                            Looking for the top house construction contractors in Bangalore? Although Bangalore's urban landscape is extensive and competitive, finding the right one can be daunting. At Builld Amaze, we make it easier by providing an effortless merge of quality, dependability, and innovation. When you select us, you're not merely employing a contractor — you're in partnership with people who care about constructing homes that live up to your way of life and your dreams.

                            Our team in-house consists of veteran architects, expert consultants, visionary interior designers, and professional builders all working in complete harmony to ensure that each project is developed to your unique requirements. we undertake each process with extreme care.

                            Whether it’s a modern villa, a traditional home, or a luxurious apartment, Builld Amaze ensures that your perspective shapes every brick and beam. With cutting-edge technology, transparent processes, and a commitment to timelines and budgets, we’ve earned the trust of hundreds of homeowners across Bangalore.

                            Let us turn your dream home into a reality — with clarity, creativity, and craftsmanship that lasts a lifetime.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-5">
        <div class="col-lg-12">
            <div class="section-title text-center space__bottom--40 mx-auto">
                <div class="text-center row">
                    <div class="section-title">
                        <h3 class="section-title__sub text-center" style="font-weight: bold; color: #003366;">
                            OUR CONSTRUCTION PACKAGES
                        </h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center g-4">
            <!-- SILVER Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #667eea, #764ba2); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;">SILVER</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">₹ 1,849</h6>
                    </div>
                </div>
            </div>

            <!-- GOLD Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #ff758c, #ff7eb3); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;">GOLD</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">₹ 1,949</h6>
                    </div>
                </div>
            </div>

            <!-- DIAMOND Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #43cea2, #185a9d); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center ">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;text-align: center;">DIAMOND</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);text-align: center;">₹ 2,049</h6>
                    </div>
                </div>
            </div>

            <!-- PLATINUM Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #f7971e, #ffd200); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center ">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;text-align: center;">PLATINUM</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem;text-align: center; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">₹ 2,199</h6>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--====================  End of feature area1  ====================-->

    <div class="service-section space__bottom--r120" style="margin-top: 120px; background-color: #f7f9fc;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center space__bottom--40 mx-auto">
                        <div class="text-center row">
                            <div class="section-title">
                                <h3 class="section-title__sub text-center" style="font-weight: bold; color: #003366;">
                                    OUR CONSTRUCTION PROCESS
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Repeatable service grid item block -->
                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/1.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Raise an Enquiry</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Place an enquiry and our expert support team will answer all your questions.
                                <br><br>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/2.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Meet Our Team</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Meet our team and share all your requirements and we will provide you a quotation with detailed specification and sample designs.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/3.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Hire Us</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Customize your packages and sign the agreement with booking advance.
                                <br><br>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/4.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Receive Drawings</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Our design team will provide you drawings and designs as per your requirements.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/5.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Track Progress</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Track the progress of the project and pay stage-wise as per work done.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/6.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Move In</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Happy New Home! May the walls ring with love and laughter.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- <div class="col-lg-3 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
                        <div class="text-center">
                            <img src="assets/img/process/7.png" class="img-fluid" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366;">Commence Construction & Daily Tracking</a>
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
                        <div class="text-center">
                            <img src="assets/img/process/8.png" class="img-fluid" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366;">Project Handover</a>
                            </h3>
                        </div>
                    </div>
                </div> -->

            </div>
        </div>
    </div>

    <!--====================  fun fact area ====================-->
    <div class="fun-fact-area space__bottom--r120">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- fun fact wrapper -->
                    <div class="fun-fact-wrapper fun-fact-wrapper-bg bg-img" data-bg="assets/img/backgrounds/funfact-bg.webp">
                        <div class="fun-fact-inner background-color--default-overlay background-repeat--x-bottom space__inner--y30 bg-img" data-bg="assets/img/icons/ruler-black.webp">
                            <div class="fun-fact-content-wrapper">
                                <div class="single-fun-fact">
                                    <h3 class="single-fun-fact__number counter">15</h3>
                                    <h4 class="single-fun-fact__text">Years of Experiance</h4>
                                </div>
                                <div class="single-fun-fact">
                                    <h3 class="single-fun-fact__number counter">50</h3>
                                    <h4 class="single-fun-fact__text">Projects Completed</h4>
                                </div>
                                <div class="single-fun-fact">
                                    <h3 class="single-fun-fact__number counter">100</h3>
                                    <h4 class="single-fun-fact__text">Happy Family</h4>
                                </div>
                                <!-- <div class="single-fun-fact">
                                    <h3 class="single-fun-fact__number counter">10</h3>
                                    <h4 class="single-fun-fact__text">On-Going Projects</h4>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of fun fact area  ====================-->
    <!--====================  project area ====================-->
    <div class="project-area " style="height: 100%;">
        <div class="container" style="height: 100%;">
            <div class="row" style="height: 100%;">
                <div class="col-lg-12">
                    <!-- Section Title -->
                    <div class="section-title text-center space__bottom--40 mx-auto">
                        <h3 class="section-title__title">Our Projects</h3>
                    </div>

                    <!-- Tabs -->
                    <ul class="nav nav-pills custom-tabs justify-content-center mb-4" id="projectTabs" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab">
                                <i class="fas fa-layer-group me-2"></i>ALL
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="video-tab" data-bs-toggle="tab" data-bs-target="#video" type="button" role="tab">
                                <i class="fas fa-video me-2"></i>Videos
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="residential-tab" data-bs-toggle="tab" data-bs-target="#residential" type="button" role="tab">
                                <i class="fas fa-home me-2"></i>Residential
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="commercial-tab" data-bs-toggle="tab" data-bs-target="#commercial" type="button" role="tab">
                                <i class="fas fa-building me-2"></i>Commercial
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="interior-tab" data-bs-toggle="tab" data-bs-target="#interior" type="button" role="tab">
                                <i class="fas fa-couch me-2"></i>Interiors
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="others-tab" data-bs-toggle="tab" data-bs-target="#others" type="button" role="tab">
                                <i class="fas fa-puzzle-piece me-2"></i>Unique Projects
                            </button>
                        </li>
                    </ul>

                    <style>
                        .custom-tabs .nav-link {
                        border-radius: 30px;
                        margin: 5px;
                        padding: 10px 20px;
                        font-weight: 600;
                        color: white;
                        background-color: #17263b;
                        border: none;
                        transition: all 0.3s ease-in-out;
                    }

                    .custom-tabs .nav-link:hover {
                        background-color: #bae6fd;
                        color: #facc15;
                    }

                    .custom-tabs .nav-link.active {
                        background-color: #0ea5e9;
                        color: #17263b;;
                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                    }
                    </style>



                    <!-- Tab Content -->
                    <div class="tab-content" id="projectTabsContent">
                        <!-- All Tab -->
                        <div class="tab-pane fade show active" id="all" role="tabpanel">
                            <div class="row">
                                <div class="col-12 col-md-4">
                                    <iframe
                                        width="100%"
                                        height="100%"
                                        src="https://www.youtube.com/embed/nNPJEwTIgdw?showinfo=0"
                                        title="YouTube video player"
                                        frameborder="0"
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen>
                                    </iframe>
                                </div>
                                <div class="col-12 col-md-4">
                                    <iframe
                                        width="100%"
                                        height="100%"
                                        src="https://www.youtube.com/embed/qNZA3gq_0WU?showinfo=0"
                                        title="YouTube video player"
                                        frameborder="0"
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen>
                                    </iframe>
                                </div>
                                <div class="col-12 col-md-4">
                                    <iframe
                                        width="100%"
                                        height="100%"
                                        src="https://www.youtube.com/embed/wIxd2d_QoKQ"
                                        title="YouTube video player"
                                        frameborder="0"
                                        allowfullscreen
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture">
                                    </iframe>
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/residential/2012-08-03 11.43.41_1_11zon.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/residential/inter3.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/residential/WhatsApp Image 2023-06-28 at 7.20.54 PM (1)_9_11zon.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/commercial/comm1.jpeg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/commercial/comm2.jpeg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/commercial/comm3.jpeg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/interior/int1.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/interior/int2.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/interior/int3.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/unique/2014-01-31 11.40.55_1_11zon.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/unique/unique2.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/unique/unique3.jpg" class="img-fluid" alt="">
                                </div>
                            </div>
                        </div>
                        <!-- Residential Tab -->
                        <div class="tab-pane fade show " id="residential" role="tabpanel">
                            <div class="row">
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/residential/2012-08-03 11.43.41_1_11zon.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/residential/inter3.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/residential/WhatsApp Image 2023-06-28 at 7.20.54 PM (1)_9_11zon.jpg" class="img-fluid" alt="">
                                </div>
                            </div>
                        </div>

                        <!-- Commercial Tab -->
                        <div class="tab-pane fade" id="commercial" role="tabpanel">
                            <div class="row">
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/commercial/comm1.jpeg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/commercial/comm2.jpeg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/commercial/comm3.jpeg" class="img-fluid" alt="">
                                </div>
                            </div>
                        </div>

                        <!-- Interior Tab -->
                        <div class="tab-pane fade" id="interior" role="tabpanel">
                            <div class="row">

                                <div class="col-12 col-md-4">
                                    <img src="assets/img/interior/int1.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/interior/int2.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/interior/int3.jpg" class="img-fluid" alt="">
                                </div>
                            </div>
                        </div>

                        <!-- Others Tab -->
                        <div class="tab-pane fade" id="others" role="tabpanel">
                            <div class="row">
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/unique/2014-01-31 11.40.55_1_11zon.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/unique/unique2.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="col-12 col-md-4">
                                    <img src="assets/img/unique/unique3.jpg" class="img-fluid" alt="">
                                </div>
                            </div>
                        </div>
                        <!-- Video Tab -->
                        <div class="tab-pane fade" id="video" role="tabpanel">
                            <div class="row">
                                <div class="col-12 col-md-4">
                                    <iframe
                                        width="100%"
                                        height="100%"
                                        src="https://www.youtube.com/embed/nNPJEwTIgdw?showinfo=0"
                                        title="YouTube video player"
                                        frameborder="0"
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen>
                                    </iframe>
                                </div>
                                <div class="col-12 col-md-4">
                                    <iframe
                                        width="100%"
                                        height="100%"
                                        src="https://www.youtube.com/embed/qNZA3gq_0WU?showinfo=0"
                                        title="YouTube video player"
                                        frameborder="0"
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen>
                                    </iframe>
                                </div>
                                <div class="col-12 col-md-4">
                                    <iframe
                                        width="100%"
                                        height="100%"
                                        src="https://www.youtube.com/embed/wIxd2d_QoKQ"
                                        title="YouTube video player"
                                        frameborder="0"
                                        allowfullscreen
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture">
                                    </iframe>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.tab-content -->
                </div>
            </div>
        </div>
    </div>

    <!--====================  End of project area  ====================-->
    <!--====================  team area ====================-->
    <!-- <div class="team-area space__bottom--r120 position-relative">
        <div class="container">
            <div class="row">
              <h3 class="section-title__sub text-center">HOW WE WORK</h3>
                <div class="col-lg-12 space__bottom__md--40 space__bottom__lm--40">
                    <div class="text-center">
                     <img src="assets/img/how-we-work2.jpg" style="width:100%">
                    </div>
                </div>
               
            </div>
        </div>
    </div>-->
    <!--====================  End of team area  ====================-->

</div>
<!--====================  testimonial cta area ====================-->
<!--====================  testimonial area ====================-->
<!-- Testimonials Section -->

<!-- Bootstrap Carousel for Testimonials -->
<div class="testimonial-area py-5" style="background-color: #f8fbff;">
    <div class="text-center mb-4">
        <h3 class="section-title__sub" style="color: #facc15;">Testimonials</h3>
        <h3 style="color: #17263b;">What our clients say</h3>
    </div>

    <div class="carousel-wrapper">
        <div class="carousel-track" id="testimonialTrack">
            <!-- Card 1 -->
            <div class="testimonial-card">
                <h5 class="fw-bold" style="color: #17263b;">Prakash Selvaraj</h5>
                <p class="text-muted">Customer</p>
                <p>Builld Amaze made the home construction process simple and smooth. Vinay was supportive throughout, and the final result was excellent.</p>
                <div class="text-warning">★★★★★</div>
            </div>

            <!-- Card 2 -->
            <div class="testimonial-card">
                <h5 class="fw-bold" style="color: #17263b;">Nikhil Gowda</h5>
                <p class="text-muted">Customer</p>
                <p>Our entire journey was smooth. Their guidance through BESCOM & BWSSB was great. We’ve recommended them to others too.</p>
                <div class="text-warning">★★★★★</div>
            </div>

            <!-- Card 3 -->
            <div class="testimonial-card">
                <h5 class="fw-bold" style="color: #17263b;">Sushma Karnam</h5>
                <p class="text-muted">Customer</p>
                <p>Excellent coordination and transparent process. No hidden costs. Great communication and quality work from Builld Amaze.</p>
                <div class="text-warning">★★★★★</div>
            </div>

            <!-- Card 4 -->
            <div class="testimonial-card">
                <h5 class="fw-bold" style="color: #17263b;">Mohit Garg</h5>
                <p class="text-muted">Customer</p>
                <p>A trustworthy and creative team. Their designs are unique, and their service quality is outstanding.</p>
                <div class="text-warning">★★★★★</div>
            </div>
        </div>
    </div>
</div>


<!-- Add this CSS below -->
<style>
    .carousel-wrapper {
        overflow: hidden;
        max-width: 100%;
        padding: 0 40px;
    }

    .carousel-track {
        display: flex;
        gap: 20px;
        transition: transform 0.6s ease-in-out;
    }

    .testimonial-card {
        flex: 0 0 70.3333%;
        background: #fff;
        border: 2px solid #facc15;
        /* Yellow border */
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 8px rgba(23, 38, 59, 0.1);
        text-align: center;
        min-height: 300px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .testimonial-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 8px 16px rgba(250, 204, 21, 0.4);
        border-color: #17263b;
        /* Dark blue on hover */
    }

    .testimonial-card p {
        color: #555;
        font-size: 0.95rem;
    }
</style>

<script>
    const track = document.getElementById('testimonialTrack');
    const cards = track.children;
    let currentIndex = 0;

    function scrollCarousel() {
        const cardWidth = cards[0].offsetWidth + 20; // card + gap
        currentIndex++;

        if (currentIndex > cards.length - 3) {
            track.appendChild(track.firstElementChild);
            track.style.transition = 'none';
            track.style.transform = `translateX(0px)`;
            currentIndex = 0;
            void track.offsetWidth; // force reflow
            setTimeout(() => {
                track.style.transition = 'transform 0.6s ease-in-out';
                track.style.transform = `translateX(-${cardWidth}px)`;
                currentIndex = 1;
            }, 50);
        } else {
            track.style.transform = `translateX(-${cardWidth * currentIndex}px)`;
        }
    }

    setInterval(scrollCarousel, 3000);
</script>



<!--====================  End of testimonial area  ====================-->
<!--====================  End of testimonial cta area  ====================-->

<script src="assets/js/easy_background.js"></script>
<script>
    // Wait until DOM is fully loaded
    document.addEventListener("DOMContentLoaded", function() {
        easy_background(".slider-bg", {
            slide: [
                "assets/img/hero-slider/1.jpg",
                "assets/img/hero-slider/2.jpg",
                "assets/img/hero-slider/3.jpg",
                "assets/img/hero-slider/4.jpg",

            ],
            delay: [2000, 2000, 2000]
        });
    });
</script>
<script>
    const slider = document.querySelector('.testimonial-slider');

    if (slider) {
        let scrollAmount = 0;
        const scrollStep = slider.clientWidth; // full width per testimonial
        const maxScrollLeft = slider.scrollWidth - slider.clientWidth;

        function autoScroll() {
            scrollAmount += scrollStep;
            if (scrollAmount > maxScrollLeft) {
                scrollAmount = 0; // loop back to start
            }
            slider.scrollTo({
                left: scrollAmount,
                behavior: 'smooth',
            });
        }

        setInterval(autoScroll, 4000); // scroll every 4 seconds
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php include('footer.php'); ?>