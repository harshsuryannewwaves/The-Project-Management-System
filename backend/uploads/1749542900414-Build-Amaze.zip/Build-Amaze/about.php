<?php include('header.php'); ?>
<style>
    .header-top-info {
        display: flex !important;
        align-items: center !important;
    }

    .header-top-info.text-end {
        justify-content: flex-end !important;
    }

    .header-top-info.text-center {
        justify-content: center !important;
    }

    .header-top-info__image {
        padding-right: 0.5rem !important;
    }
</style>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: '#1e40af', // Deep blue
                    secondary: '#fcd34d' // Warm yellow
                }
            }
        }
    }
</script>
<style>
    .fadeInUp {
    opacity: 0;
    transform: translateY(30px);
    animation: fadeInUp 1s ease forwards;
}

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

    @media only screen and (max-width: 767px) {
        #hero-section-about{
            margin-top: 0px;
        }
    }
</style>
<!-- Hero Section -->
<section id="hero-section-about" class="relative  text-white  pt-4 pb-1 sm:mt-0 lg:mt-[80px] z-0" style="background: #17263b;">
    <!-- <div class="absolute inset-0 opacity-20 bg-pattern"></div> -->
    <div class=" mx-auto px-4 text-center relative z-10 mt-4">
        <h1 class="text-4xl md:text-6xl font-bold mb-6 text-white ">About Builld Amaze</h1>
    </div>
</section>

<!-- Main Content -->
<main id="profile" class=" mx-auto px-4 z-0">
    <!-- Section 1: Crafting Enduring Legacies -->
   <section class="py-8 bg-white">
    <div class="max-w-6xl mx-auto px-6 md:px-12 lg:px-16">
        <div class="text-center mb-12">                                                                                             
            <h2 class="text-2xl text-yellow-500 font-semibold">Crafting Your Dream Home</h2>
            <div class="mt-4 w-20 h-1 bg-yellow-400 mx-auto rounded-full"></div>
        </div>

        <div class="text-center text-gray-700 text-lg space-y-6 leading-relaxed font-bold fadeInUp" style="animation-delay: 0.2s;">
            <p>
                At Builld Amaze, we don't just construct buildings; we bring visions to life. Our founder's enduring foresight laid the groundwork for a company built on innovation, knowledge, and a deep understanding of what truly matters to our clients.
            </p>
            <p>
                As a trusted construction company, we are renowned for our meticulous execution and unwavering commitment to quality. But we offer much more. Our expert architectural designers transform your aspirations into stunning, functional blueprints, while our bespoke interior solutions ensure every corner of your dream home reflects your unique style and comfort.
            </p>
            <p>
                We are bold in our approach, constantly seeking purposeful outcomes and shared visions with our clients. This is how we consistently deliver on our promise: to Builld Amaze for your home.
            </p>
        </div>
    </div>
</section>


    <!-- Section 2: Unrivalled Scope -->
    <section class="mb-24">
        <div class="flex flex-col md:flex-row-reverse items-center">
            <div class="md:w-1/2 mb-8 md:mb-0 md:pl-8">
                <img src="assets/img/commercial/comm3.jpeg"
                    alt="Unrivalled scope"
                    class="rounded-xl shadow-2xl transform transition duration-700 hover:scale-105">
            </div>
            <div class="md:w-1/2">
                <h2 class="text-3xl md:text-4xl font-bold mb-6 " style="color: #17263b;">Unrivalled Scope, Uncompromising Quality</h2>
                <p class="text-gray-700 text-lg mb-6">
                    Builld Amaze redefines comprehensive construction. Our expertise spans the entire project lifecycle, from incubating the latest design trends and rigorous planning to the flawless execution of diverse ventures. Whether it's the precision of industrial construction, the grandeur of commercial complexes, or the intimacy of residential projects, our commitment to excellence remains unwavering. Furthermore, our capabilities extend to pivotal land development and all facets of civil work, offering an end-to-end solution for any construction need.
                </p>
                <div class="flex items-center space-x-2 text-secondary">
                    <div class="w-12 h-1 bg-secondary"></div>
                    <i class="fas fa-hard-hat text-xl"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Section 3: Our Foundation -->
    <section class="mb-24">
        <div class="flex flex-col md:flex-row items-center">
            <div class="md:w-1/2 mb-8 md:mb-0 md:pr-8">
                <img src="assets/img/interior/int4.jpg"
                    alt="Our foundation"
                    class="rounded-xl shadow-2xl transform transition duration-700 hover:scale-105">
            </div>
            <div class="md:w-1/2">
                <h2 class="text-3xl md:text-4xl font-bold mb-6 " style="color: #17263b;">Our Foundation: Trust, Reliability, and Satisfaction</h2>
                <p class="text-gray-700 text-lg mb-6">
                    Our enduring success is built on the pillars of trust, reliability, and unparalleled customer satisfaction. We stand by our verified testimonials from a discerning clientele who have experienced our commitment firsthand. For us, every project is a partnership, driven by a dedication to exceeding expectations rather than merely pursuing profit. This ethos has enabled Builld Amaze to consistently set world-class benchmarks in engineering excellence, uphold rigorous quality processes, leverage cutting-edge technology, and cultivate lasting customer relationships through the delivery of truly efficient construction solutions.
                </p>
                <div class="flex items-center space-x-2 text-secondary">
                    <div class="w-12 h-1 bg-secondary"></div>
                    <i class="fas fa-handshake text-xl"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Section 4: Testament to Excellence -->
    <section>
        <div class="flex flex-col md:flex-row-reverse items-center">
            <div class="md:w-1/2 mb-8 md:mb-0 md:pl-8">
                <img src="assets/img/unique/unique3.jpg"
                    alt="Testament to excellence"
                    class="rounded-xl shadow-2xl transform transition duration-700 hover:scale-105">
            </div>
            <div class="md:w-1/2">
                <h2 class="text-3xl md:text-4xl font-bold mb-6 " style="color: #17263b;">A Testament to Excellence</h2>
                <p class="text-gray-700 text-lg mb-6">
                    Every structure bearing the Builld Amaze name is a powerful testament to our unwavering commitment to quality, an acute eye for detail, technical mastery, refined aesthetic sensibility, and an insatiable passion for excellence. Our completed projects don't just stand tall; they embody our dedication to crafting spaces that are not only supremely functional but also architecturally stunning and built to endure for generations.
                </p>
                <div class="flex items-center space-x-2 text-secondary">
                    <div class="w-12 h-1 bg-secondary"></div>
                    <i class="fas fa-medal text-xl"></i>
                </div>
            </div>
        </div>
    </section>
    <div id="packages" class="container my-5">
        <div class="col-lg-12">
            <div class="section-title text-center space__bottom--40 mx-auto">
                <div class="text-center row">
                    <div class="section-title">
                        <h3 class="section-title__sub text-center" style="font-weight: bold; color: #003366;">
                            OUR CONSTRUCTION PACKAGES
                        </h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center g-4">
            <!-- SILVER Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #667eea, #764ba2); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;">SILVER</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">₹ 1,849</h6>
                    </div>
                </div>
            </div>

            <!-- GOLD Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #ff758c, #ff7eb3); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;">GOLD</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">₹ 1,949</h6>
                    </div>
                </div>
            </div>

            <!-- DIAMOND Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #43cea2, #185a9d); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center ">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;text-align: center;">DIAMOND</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);text-align: center;">₹ 2,049</h6>
                    </div>
                </div>
            </div>

            <!-- PLATINUM Package -->
            <div class="col-md-3">
                <div class="card text-white text-center h-100" style="background: linear-gradient(135deg, #f7971e, #ffd200); border: none; border-radius: 15px;">
                    <div class="card-body d-flex flex-column justify-content-center ">
                        <h5 class="card-title fw-bold mb-3" style="font-size: 1.5rem;text-align: center;">PLATINUM</h5>
                        <h6 class="card-subtitle fw-bold" style="font-size: 2rem;text-align: center; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">₹ 2,199</h6>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div id="process" class="service-section " style="margin-top: 120px; background-color: #f7f9fc;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center space__bottom--40 mx-auto">
                        <div class="text-center row">
                            <div class="section-title">
                                <h3 class="section-title__sub text-center" style="font-weight: bold; color: #003366;">
                                    OUR CONSTRUCTION PROCESS
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Repeatable service grid item block -->
                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/1.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Raise an Enquiry</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Place an enquiry and our expert support team will answer all your questions.
                                <br><br>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/2.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Meet Our Team</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Meet our team and share all your requirements and we will provide you a quotation with detailed specification and sample designs.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/3.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Hire Us</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Customize your packages and sign the agreement with booking advance.
                                <br><br>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/4.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Receive Drawings</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Our design team will provide you drawings and designs as per your requirements.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/5.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Track Progress</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Track the progress of the project and pay stage-wise as per work done.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border: 1px solid #ccc; border-radius: 10px; padding: 24px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">

                        <div class="text-center">
                            <img src="assets/img/process/6.png" class="img-fluid mx-auto d-block" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366; font-weight: bold;">
                                    Move In</a>
                            </h3>
                            <p class="text-center" style="color: #555; font-size: 15px; margin-top: 10px; font-weight: bold;">

                                Happy New Home! May the walls ring with love and laughter.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- <div class="col-lg-3 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
                        <div class="text-center">
                            <img src="assets/img/process/7.png" class="img-fluid" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366;">Commence Construction & Daily Tracking</a>
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-12 space__bottom--40">
                    <div class="service-grid-item" style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
                        <div class="text-center">
                            <img src="assets/img/process/8.png" class="img-fluid" alt="" />
                        </div>
                        <div class="service-grid-item__content">
                            <h3 class="text-center title">
                                <a style="font-size: 20px; color: #003366;">Project Handover</a>
                            </h3>
                        </div>
                    </div>
                </div> -->

            </div>
        </div>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include('footer.php'); ?>