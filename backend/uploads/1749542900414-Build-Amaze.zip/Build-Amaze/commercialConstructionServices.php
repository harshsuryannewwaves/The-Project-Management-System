<?php include('header.php'); ?>

<script src="https://cdn.tailwindcss.com"></script>
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

    /* body {
        font-family: 'Poppins', sans-serif;
        background-color: #f8f9fa;
    } */

    .gradient-highlight {
        background: #17263b;
    }

    .hover-tilt:hover {
        transform: perspective(1000px) rotateY(5deg) rotateX(2deg) scale(1.03);
        transition: transform 0.3s ease;
    }

    .section-divider {
        height: 4px;
        background: linear-gradient(90deg, #fcd34d 0%, #f59e0b 100%);
    }
</style>
<style>
    .header-top-info {
        display: flex !important;
        align-items: center !important;
    }

    .header-top-info.text-end {
        justify-content: flex-end !important;
    }

    .header-top-info.text-center {
        justify-content: center !important;
    }

    .header-top-info__image {
        padding-right: 0.5rem !important;
    }
</style>
<style>
    @media only screen and (max-width: 767px) {
        #hero-section-about {
            margin-top: 0px !important;
        }
    }
</style>
<!-- Hero Section -->
<div id="#hero-section-about" class="relative overflow-hidden gradient-highlight sm:mt-0 lg:mt-[80px]">
    <div class="container mx-auto px-4 py-16 text-center">
        <h1 class="text-4xl md:text-6xl font-bold text-white mb-6">
            <span class="block">Commercial Construction</span>
            <span class="text-yellow-300">Services</span>
        </h1>
        <p class="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Building Foundations for Your Business Success
        </p>
    </div>
    <div class="absolute bottom-0 left-0 right-0 h-2 bg-yellow-400"></div>
</div>

<!-- About Section -->
<!-- <section id="about" class="py-16 bg-lightyellow">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row items-center">
            <div class="md:w-1/2 mb-10 md:mb-0 md:pr-10">
                <div class="relative">
                    <img src="assets/img/commercial/comm3.jpeg"
                        alt="Construction Team"
                        class="rounded-lg shadow-xl w-full">
                    <div class="absolute -bottom-6 -right-6  text-white p-6 rounded-lg shadow-lg max-w-xs" style="background-color: #17263b;">
                        <h3 class="font-bold text-xl mb-2 text-white">15+ Years Experience</h3>
                        <p class="text-sm">Trusted by homeowners across Bangalore</p>
                    </div>
                </div>
            </div>
            <div class="md:w-1/2">
                <h2 class="text-3xl font-bold  mb-6" style="color: #17263b;">About BuilldAmaze</h2>
                <p class="text-gray-700 mb-4">At Builld Amaze, we understand that commercial spaces are more than just structures; they are dynamic environments critical to your business's growth, efficiency, and brand identity. As a leading commercial construction contractor in Bangalore, we specialize in delivering tailored, high-performance solutions that empower your enterprise to thrive.</p>
                <p class="text-gray-700 mb-6">We combine innovative design, robust engineering, and meticulous project management to construct spaces that are not only functional and aesthetically superior but also strategically aligned with your operational goals.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <div class="flex items-start">
                        <i class="fa fa-check-circle text-secondary text-xl mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-bold " style="color: #17263b;">Quality Materials</h4>
                            <p class="text-gray-600 text-sm">Only the best materials for lasting durability</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <i class="fa fa-check-circle text-secondary text-xl mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-bold " style="color: #17263b;">Skilled Professionals</h4>
                            <p class="text-gray-600 text-sm">Highly trained and experienced craftsmen</p>
                        </div>
                    </div>
                </div>
                <a href="about.php" class="inline-flex items-center font-bold hover:text-darkblue" style="color: #17263b;">
                    Learn More About Us
                    <i class="fa fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</section> -->

<!-- Expertise Section -->
<div class="bg-white shadow-xl rounded-lg overflow-hidden container mx-auto px-6 py-12 max-w-6xl">
    <h2 class="text-3xl md:text-4xl font-bold text-center text-primary-900 mb-12">
        Our Expertise Across Commercial Sectors
    </h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Expertise Card 1 -->
        <div class="expertise-card bg-primary-50 rounded-xl p-6 border-1 border-yellow-300 transition-transform transform hover:scale-105 hover:shadow-xl duration-300">
            <div class="flex items-center mb-4">
                <div class="icon-wrapper bg-yellow-100 p-3 rounded-lg mr-4 transition-all duration-300">
                    <i class="fas fa-building text-yellow-600 text-xl animate-pulse-on-hover"></i>
                </div>
                <h3 class="text-xl font-bold text-primary-900">Office Buildings & Corporate Campuses</h3>
            </div>
            <p class="text-primary-800">
                Creating modern, inspiring, and efficient workspaces that foster collaboration, productivity,
                and employee well-being, from cutting-edge tech parks to elegant corporate headquarters.
            </p>
        </div>

        <!-- Expertise Card 2 -->
        <div class="expertise-card bg-primary-50 rounded-xl p-6 border-1 border-yellow-300 transition-transform transform hover:scale-105 hover:shadow-xl duration-300">
            <div class="flex items-center mb-4">
                <div class="icon-wrapper bg-yellow-100 p-3 rounded-lg mr-4 transition-all duration-300">
                    <i class="fa fa-shopping-cart text-yellow-600 text-xl animate-pulse-on-hover"></i>
                </div>
                <h3 class="text-xl font-bold text-primary-900">Retail Spaces & Shopping Centers</h3>
            </div>
            <p class="text-primary-800">
                Designing and constructing vibrant, engaging retail environments that attract customers, enhance brand visibility,
                and drive sales, from standalone stores to large-scale malls.
            </p>
        </div>

        <!-- Expertise Card 3 -->
        <div class="expertise-card bg-primary-50 rounded-xl p-6 border-1 border-yellow-300 transition-transform transform hover:scale-105 hover:shadow-xl duration-300">
            <div class="flex items-center mb-4">
                <div class="icon-wrapper bg-yellow-100 p-3 rounded-lg mr-4 transition-all duration-300">
                    <i class="fa fa-city text-yellow-600 text-xl animate-pulse-on-hover"></i>
                </div>
                <h3 class="text-xl font-bold text-primary-900">Industrial Facilities & Warehouses</h3>
            </div>
            <p class="text-primary-800">
                Developing robust and optimized industrial structures, including manufacturing plants, logistics hubs,
                and storage facilities, built for maximum operational efficiency and safety.
            </p>
        </div>

        <!-- Expertise Card 4 -->
        <div class="expertise-card bg-primary-50 rounded-xl p-6 border-1 border-yellow-300 transition-transform transform hover:scale-105 hover:shadow-xl duration-300">
            <div class="flex items-center mb-4">
                <div class="icon-wrapper bg-yellow-100 p-3 rounded-lg mr-4 transition-all duration-300">
                    <i class="fa fa-umbrella-beach text-yellow-600 text-xl animate-pulse-on-hover"></i>
                </div>
                <h3 class="text-xl font-bold text-primary-900">Hospitality & Leisure Developments</h3>
            </div>
            <p class="text-primary-800">
                Constructing hotels, resorts, restaurants, and entertainment venues that offer exceptional guest experiences
                and reflect a distinct brand character.
            </p>
        </div>

        <!-- Expertise Card 5 -->
        <div class="expertise-card bg-primary-50 rounded-xl p-6 border-1 border-yellow-300 transition-transform transform hover:scale-105 hover:shadow-xl duration-300">
            <div class="flex items-center mb-4">
                <div class="icon-wrapper bg-yellow-100 p-3 rounded-lg mr-4 transition-all duration-300">
                    <i class="fa fa-graduation-cap text-yellow-600 text-xl animate-pulse-on-hover"></i>
                </div>
                <h3 class="text-xl font-bold text-primary-900">Educational Institutions</h3>
            </div>
            <p class="text-primary-800">
                Building state-of-the-art schools, colleges, and research facilities designed to facilitate learning,
                innovation, and community engagement.
            </p>
        </div>

        <!-- Expertise Card 6 -->
        <div class="expertise-card bg-primary-50 rounded-xl p-6 border-1 border-yellow-300 transition-transform transform hover:scale-105 hover:shadow-xl duration-300">
            <div class="flex items-center mb-4">
                <div class="icon-wrapper bg-yellow-100 p-3 rounded-lg mr-4 transition-all duration-300">
                    <i class="fa fa-hospital text-yellow-600 text-xl animate-pulse-on-hover"></i>
                </div>
                <h3 class="text-xl font-bold text-primary-900">Healthcare Facilities</h3>
            </div>
            <p class="text-primary-800">
                Constructing modern clinics, hospitals, and specialized medical centers that prioritize patient care,
                technological integration, and stringent safety standards.
            </p>
        </div>
    </div>
</div>

<!-- Approach Section -->
<div class="container mx-auto px-6 py-20">
    <div class="max-w-4xl mx-auto">
        <h2 class="text-3xl md:text-4xl font-bold text-center text-primary-900 mb-16">
            Our Integrated Approach to Commercial Construction
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Approach Card -->
            <div class="approach-card bg-white border-1 border-yellow-300 rounded-xl p-6 transition-transform transform hover:scale-105 shadow-md hover:shadow-xl duration-300">
                <div class="flex items-start">
                    <div class="icon-wrapper bg-yellow-400 rounded-full p-3 mr-4 flex-shrink-0 transition-transform duration-300">
                        <i class="fa fa-search-plus text-white text-lg animate-on-hover"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-primary-900 mb-2">Pre-Construction & Feasibility</h3>
                        <p class="text-primary-800">
                            Comprehensive site analysis, feasibility studies, detailed budgeting, and value engineering
                            to optimize your investment and mitigate risks.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Repeat structure for other cards below, changing icon & text only -->

            <div class="approach-card bg-white border-1 border-yellow-300 rounded-xl p-6 transition-transform transform hover:scale-105 shadow-md hover:shadow-xl duration-300">
                <div class="flex items-start">
                    <div class="icon-wrapper bg-yellow-400 rounded-full p-3 mr-4 flex-shrink-0 transition-transform duration-300">
                        <i class="fa fa-pencil-ruler text-white text-lg animate-on-hover"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-primary-900 mb-2">Design-Build Solutions</h3>
                        <p class="text-primary-800">
                            Streamlining the construction process by integrating design and construction phases,
                            ensuring cohesive planning, cost efficiency, and faster project delivery.
                        </p>
                    </div>
                </div>
            </div>

            <div class="approach-card bg-white border-1 border-yellow-300 rounded-xl p-6 transition-transform transform hover:scale-105 shadow-md hover:shadow-xl duration-300">
                <div class="flex items-start">
                    <div class="icon-wrapper bg-yellow-400 rounded-full p-3 mr-4 flex-shrink-0 transition-transform duration-300">
                        <i class="fa fa-leaf text-white text-lg animate-on-hover"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-primary-900 mb-2">Sustainable Construction Practices</h3>
                        <p class="text-primary-800">
                            Incorporating eco-friendly materials and energy-efficient systems to reduce operational costs,
                            minimize environmental impact, and achieve green building certifications.
                        </p>
                    </div>
                </div>
            </div>

            <div class="approach-card bg-white border-1 border-yellow-300 rounded-xl p-6 transition-transform transform hover:scale-105 shadow-md hover:shadow-xl duration-300">
                <div class="flex items-start">
                    <div class="icon-wrapper bg-yellow-400 rounded-full p-3 mr-4 flex-shrink-0 transition-transform duration-300">
                        <i class="fa fa-tasks text-white text-lg animate-on-hover"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-primary-900 mb-2">Advanced Project Management</h3>
                        <p class="text-primary-800">
                            Utilizing cutting-edge tools and methodologies for precise scheduling, resource allocation,
                            quality control, and transparent progress reporting.
                        </p>
                    </div>
                </div>
            </div>

            <div class="approach-card bg-white border-1 border-yellow-300 rounded-xl p-6 transition-transform transform hover:scale-105 shadow-md hover:shadow-xl duration-300">
                <div class="flex items-start">
                    <div class="icon-wrapper bg-yellow-400 rounded-full p-3 mr-4 flex-shrink-0 transition-transform duration-300">
                        <i class="fa fa-file-alt text-white text-lg animate-on-hover"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-primary-900 mb-2">Strict Adherence to Regulations</h3>
                        <p class="text-primary-800">
                            Ensuring all projects comply with local building codes, safety regulations,
                            and environmental standards, guaranteeing a legally sound and secure facility.
                        </p>
                    </div>
                </div>
            </div>

            <div class="approach-card bg-white border-1 border-yellow-300 rounded-xl p-6 transition-transform transform hover:scale-105 shadow-md hover:shadow-xl duration-300">
                <div class="flex items-start">
                    <div class="icon-wrapper bg-yellow-400 rounded-full p-3 mr-4 flex-shrink-0 transition-transform duration-300">
                        <i class="fa fa-clock text-white text-lg animate-on-hover"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-primary-900 mb-2">Timely & Budget-Conscious Delivery</h3>
                        <p class="text-primary-800">
                            Our commitment to efficiency ensures your project is completed on time and within budget,
                            minimizing downtime and maximizing your return on investment.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    @keyframes iconBounce {

        0%,
        100% {
            transform: translateY(0);
        }

        50% {
            transform: translateY(-6px);
        }
    }

    .approach-card:hover .icon-wrapper i {
        animation: iconBounce 0.5s ease-in-out;
    }
</style>

<!-- Benefits Section with Cards -->
<div class="bg-primary-900 py-20">
    <div class="container mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-black mb-4">
                Why Partner with <span class="text-yellow-400">Builld Amaze</span> for Your Commercial Project?
            </h2>
            <p class="text-xl text-blue-600 max-w-3xl mx-auto">
                We deliver more than buildings - we create strategic assets for your business.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            <!-- Benefit Card 1 -->
            <div class="bg-white border border-[#17263b] rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:scale-105 duration-300">
                <div class="bg-yellow-400 h-2"></div>
                <div class="p-6">
                    <div class="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
                        <i class="fas fa-eye text-primary-800 text-4xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-center text-primary-900 mb-3">Strategic Vision</h3>
                    <p class="text-primary-800 text-justify">We go beyond blueprints, understanding your business objectives to deliver spaces that truly support your strategic goals.</p>
                </div>
            </div>

            <!-- Benefit Card 2 -->
            <div class="bg-white border border-[#17263b] rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:scale-105 duration-300">
                <div class="bg-yellow-400 h-2"></div>
                <div class="p-6">
                    <div class="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
                        <i class="fas fa-award text-primary-800 text-4xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-center text-primary-900 mb-3">Proven Track Record</h3>
                    <p class="text-primary-800 text-justify">
                        A robust portfolio of successful commercial projects demonstrates our capability and commitment to excellence.
                    </p>
                </div>
            </div>

            <!-- Benefit Card 3 -->
            <div class="bg-white border border-[#17263b] rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:scale-105 duration-300">
                <div class="bg-yellow-400 h-2"></div>
                <div class="p-6">
                    <div class="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
                        <i class="fas fa-building text-primary-800 text-4xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-center text-primary-900 mb-3">Quality & Durability</h3>
                    <p class="text-primary-800 text-justify">
                        We prioritize premium materials and superior craftsmanship for facilities built for longevity and performance.
                    </p>
                </div>
            </div>

            <!-- Benefit Card 4 -->
            <div class="bg-white border border-[#17263b] rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:scale-105 duration-300">
                <div class="bg-yellow-400 h-2"></div>
                <div class="p-7">
                    <div class="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
                        <i class="fas fa-robot text-primary-800 text-4xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-center text-primary-900 mb-3">Innovation & Technology</h3>
                    <p class="text-primary-800 text-justify">
                        Embracing the latest construction technologies to deliver future-ready and energy-efficient commercial spaces.
                    </p>
                </div>
            </div>

            <!-- Benefit Card 5 -->
            <div class="bg-white border border-[#17263b] rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all hover:scale-105 duration-300">
                <div class="bg-yellow-400 h-2"></div>
                <div class="p-6">
                    <div class="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mb-4 mx-auto">
                        <i class="fas fa-users text-primary-800 text-4xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-center text-primary-900 mb-3">Reliability & Trust</h3>
                    <p class="text-primary-800 text-justify">
                        We are dedicated to fostering long-term partnerships built on transparency, clear communication, and a shared commitment to your success.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Projects Gallery -->
<section id="projects" class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-bold  mb-4" style="color: #17263b;">Our Recent Projects</h2>
            <div class="w-24 h-1 bg-secondary mx-auto"></div>
            <p class="text-gray-600 mt-4 max-w-3xl mx-auto">Browse through our portfolio of exceptional commercial projects in Bangalore.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/commercial/comm1.jpeg"
                    alt="Modern Villa Project"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/commercial/comm2.jpeg"
                    alt="Contemporary Apartment"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/commercial/comm4.jpeg"
                    alt="Heritage Bungalow"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

            <div class="relative group overflow-hidden rounded-lg shadow-lg cursor-pointer" onclick="openModal(this)">
                <img src="assets/img/commercial/comm5.jpeg"
                    alt="Luxury Penthouse"
                    class="w-full h-64 object-cover transition duration-500 group-hover:scale-110">

            </div>

        </div>
    </div>
</section>
<!-- Modal -->
<div id="imageModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black bg-opacity-70">
    <div class="relative bg-white p-4 rounded-lg shadow-lg max-w-2xl w-full max-h-[65vh] overflow-auto">
        <button onclick="closeModal()" class="absolute top-2 right-1 text-black text-6xl font-bold">&times;</button>

        <!-- Left Arrow -->
        <button onclick="prevImage()" class="absolute left-1 top-1/2 transform -translate-y-1/2 text-4xl text-gray-600 hover:text-black z-10">
            &#10094;
        </button>

        <!-- Right Arrow -->
        <button onclick="nextImage()" class="absolute right-1 top-1/2 transform -translate-y-1/2 text-4xl text-gray-600 hover:text-black z-10">
            &#10095;
        </button>

        <img id="modalImage" src="" alt="Project Image" class="w-full h-auto rounded">
    </div>
</div>
<style>
    #imageModal button {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0 10px;
}

</style>

<!-- Final CTA -->
<div class="bg-gradient-to-r from-yellow-400 to-yellow-500 py-16">
    <div class="container mx-auto px-6 text-center">
        <h2 class="text-3xl md:text-4xl font-bold text-primary-900 mb-6">
            Build Your Business Future with Builld Amaze
        </h2>
        <p class="text-xl text-primary-900 max-w-3xl mx-auto mb-8">
            Invest in a commercial space that elevates your brand, enhances your operations,
            and provides a solid foundation for future growth.
        </p>

    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const imageSources = [
        "assets/img/commercial/comm1.jpeg",
        "assets/img/commercial/comm2.jpeg",
        "assets/img/commercial/comm4.jpeg",
        "assets/img/commercial/comm5.jpeg"
    ];

    let currentIndex = 0;

    function openModal(element) {
        const imgSrc = element.querySelector('img').getAttribute('src');
        currentIndex = imageSources.indexOf(imgSrc);
        showImage(currentIndex);
        document.getElementById('imageModal').classList.remove('hidden');
        document.getElementById('imageModal').classList.add('flex');
    }

    function closeModal() {
        document.getElementById('imageModal').classList.add('hidden');
        document.getElementById('imageModal').classList.remove('flex');
    }

    function showImage(index) {
        const modalImg = document.getElementById('modalImage');
        modalImg.setAttribute('src', imageSources[index]);
    }

    function prevImage() {
        currentIndex = (currentIndex - 1 + imageSources.length) % imageSources.length;
        showImage(currentIndex);
    }

    function nextImage() {
        currentIndex = (currentIndex + 1) % imageSources.length;
        showImage(currentIndex);
    }
</script>

<?php include('footer.php'); ?>